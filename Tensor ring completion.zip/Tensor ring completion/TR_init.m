function [tnsr,g]=TR_init(I,R,method,tnsr)
g=TRcore_init(I,R,method,tnsr);
[~,~,tnsr]=tensor_ring(g,1,I);
end