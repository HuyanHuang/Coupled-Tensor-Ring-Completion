function [RE,flag]=TR_FastALS_bound(model)
%% initialize parameters
maxiter=200;
epsilon_x=1e-8;
val=model.val;
idx=model.idx;
siz=model.siz;
TRr=model.TRr;
gdt=model.gdt;
D=length(siz);
RC=nan(maxiter,1);
RE=nan(maxiter,1);
F0=norm(gdt(:),2);
flag=false;
%% preparation
W=zeros(siz);
W(idx)=1;
T=W.*reshape(1:prod(siz),siz);
C=cell(1,D);
ind=cell(1,D);
for d=1:D
    Wd=reshape(permute(W,[d d+1:D 1:d-1]),siz(d),[]);
    Td=reshape(permute(T,[d d+1:D 1:d-1]),siz(d),[]);
    for id=1:siz(d)
        ind{d}{id}=find(Wd(id,:));
        [~,~,v]=find(Td(id,:));
        [~,loc]=ismember(v,idx);
        C{d}{id}=val(loc)';
    end
end
%% tensor ring approximation
x0=initialization_M(siz,idx,val);
g=TRg_svd(x0,siz,TRr);
%% tensor ring completion
% main loop
for i=1:maxiter
    % original-BCD(block coordinate descent)
    % solve each sub-problem
    for d=1:D
        [A,B]=tensor_ring(g,d,siz);
        % slove each sub-sub-problem (update row by row)
        for id=1:siz(d)
            Bhat=B(:,ind{d}{id});
            Hess=Bhat*Bhat';
            A(id,:)=C{d}{id}*Bhat'/Hess;
        end
        g=ctensor_ring(g,d,A);
    end
    % calculate newly recovered tensor
    [~,~,x]=tensor_ring(g,1,siz);
    % compute relative error with respect to cost function
    RC(i)=norm(x(:)-x0(:),2)/norm(x0(:),2);
    RE(i)=norm(x(:)-gdt(:),2)/F0;
%     if mod(i,10)==0
%         fprintf('Iteration=%d\tRE=%f\n',i,RE(i));
%     end
    if RC(i)<epsilon_x
        flag=true;
        break
    end
    if RE(i)>100
        flag=false;
        break
    end
    x0=x;
end
end