clc
clear
close all
%% input arguments
TRr=6;
SR=0.5;
load('/Users/huanghuyan/Documents/MATLAB/Dataset/Coupled data/E_nose_data.mat')
img=NoseData.data(1:6,1:240,:);
%% ket augmentation--covert original(low-order) tensor to high-order tensor
siz=size(img);
img=double(img);
I=[6 3 4 4 5 3 4];
order=[1:length(I)];
J=[6 3 4 4 5 3 4];
tnsr=l2h(img,I,order,J);
%% sampling
[model.val,model.idx]=unisam(tnsr,SR);
%% solve
model.siz=J;
model.TRr=TRr*ones(1,length(J));
model.gdt=tnsr;
[x,RC,RMSE,run_time,g]=TR_FastALS(model,true);
%% deaugmentation--covert high-order tensor to original(low-order) tensor
x=h2l(x,I,order,siz);
% figure;
% imshow(uint8(x));
psnr(uint8(x),uint8(img))
num_para=sum(J*TRr^2);
ratio=num_para/prod(J)