function g=TRcore_init(I,R,method,tnsr)
N=length(I);
g=cell(1,N);
switch lower(method)
    case 'svd'
        g=TRcore_svd(I,R,tnsr);
    case 'gaussian'
        for i=1:N-1
            g{i}=randn(R(i),I(i),R(i+1));
        end
        g{N}=randn(R(N),I(N),R(1));
    case 'uniform'
        for i=1:N-1
            g{i}=rand(R(i),I(i),R(i+1));
        end
        g{N}=rand(R(N),I(N),R(1));
    case {'student','t'}
        for i=1:N-1
            g{i}=trnd(1,R(i),I(i),R(i+1));
        end
        g{N}=trnd(1,R(N),I(N),R(1));
    otherwise
        for i=1:N-1
            g{i}=randn(R(i),I(i),R(i+1));
        end
        g{N}=randn(R(N),I(N),R(1));
end