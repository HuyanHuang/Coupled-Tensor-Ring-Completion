clc
clear
close all
%% input arguments
D=4;
TRr=4*ones(1,D);
SR=0.1;
siz=20*ones(1,D);
lambda=0;
tnsr=TR_init(siz,TRr,'gaussian',[]);
%% sampling
[val,idx]=unisam(tnsr,SR);
%% solve
model.siz=siz;
model.TRr=TRr;
model.gdt=tnsr;
model.val=val;
model.idx=idx;
model.pnt=lambda;
[x,RC,RMSE,run_time]=TR_FastALS(model,true);
%% display the result
figure;
semilogy(RMSE);
xlabel('Iteration');
ylabel('RMSE (log_{10})');