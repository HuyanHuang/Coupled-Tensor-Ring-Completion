function g=ctensor_ring(g,d,A)
% ctensor_ring folds matrix A to the corresponding core of tensor ring
%=====================================================================
% input:
% g is the TR cores
% d is the index of TR cores
% A is the unfolding maxtrix of the d-th core
%=====================================================================
% output:
% g is the TR cores
%=====================================================================
[Rd,Id,Rd1]=size(g{d});
Gd=reshape(A,[Id,Rd,Rd1]);
g{d}=permute(Gd,[2 1 3]);
end