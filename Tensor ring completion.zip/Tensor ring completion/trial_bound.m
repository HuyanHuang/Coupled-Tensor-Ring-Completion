clc
clear
close all
%% input arguments
D=4;
I=10;
TRr=2;
SR=linspace(D*TRr^2/I^(D-1),0.2,100);
num_trial=500;
err=zeros(num_trial,length(SR));
siz=I*ones(1,D);
tnsr=TR_rand(siz,TRr*ones(1,D));
model.siz=siz;
model.TRr=TRr*ones(1,D);
model.gdt=tnsr;
%% 
warning off
for j=1:length(SR)
    j
    for i=1:num_trial
        if mod(i,10)==0
            i
        end
        % sampling
        P=zeros(I*ones(1,D));
        r=rand(I*ones(1,D));
        idx=sort(find(r<=SR(j)));
        val=tnsr(idx);
        % solve
        model.idx=idx;
        model.val=val;
        err(i,j)=TR_FastALS_bound(model,false);
    end
end
warning on
%%
save TRbound_I_10_R_2 err
p=sum(err)/num_trial;
a=I^(D-1);
b=D*TRr^2;
x=a*(SR-b/a).^2./(2*SR);
p0=(1-exp(-x)).^I;
figure;
hold on
plot(SR,p);
plot(SR,p0);
xlabel('SR');
ylabel('Probability');
legend('Practical','Theoretic');