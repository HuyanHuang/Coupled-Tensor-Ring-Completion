clc
clear
close all
%%
sigma = 10;
beta = 8/3;
rho = 28;
f = @(t,a) [-sigma*a(1) + sigma*a(2); rho*a(1) - a(2) - a(1)*a(3); -beta*a(3) + a(1)*a(2)];
xt0 = [10,20,10];
[tspan,a] = ode45(f,[0 100],xt0);
%%
SR=0.5;
model.siz=[4*ones(1,6),3];
model.TRr=8*ones(1,7);
model.gdt=reshape(a(10+(1:4096),1:3),model.siz);
[model.val,model.idx]=unisam(model.gdt,SR);
[x,RC,RE,run_time]=TR_FastALS(model,true);