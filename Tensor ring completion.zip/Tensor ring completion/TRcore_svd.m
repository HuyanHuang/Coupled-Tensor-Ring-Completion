function g=TRcore_svd(I,R,tnsr)
% initialize paprameters
D=length(I);
g=cell(1,D);
for d=1:D-1
    g{d}=randn(R(d),I(d),R(d+1));
end
g{D}=randn(R(D),I(D),R(1));
T=zeros(1,D-1);
% estimate the 1st factor
Xn=reshape(tnsr,I(1),[]);
siz=size(Xn);
T(1)=min([siz,R(2)]);
[U,S,V]=svds(Xn,T(1));
% U=U(:,1:T(1));
% S=S(1:T(1),1:T(1));
% V=V(:,1:T(1));
g{1}(1,:,1:T(1))=U*sqrt(S);
Xn=sqrt(S)*V';
% estimate the 2nd to (D-1)-th factor
for d=2:D-1
    Xn=reshape(Xn,T(d-1)*I(d),[]);
    siz=[T(d-1)*I(d),prod(I(d+1:D))];
    T(d)=min([siz,R(d+1)]);
    [U,S,V]=svds(Xn,T(d));
%     U=U(:,1:T(d));
%     S=S(1:T(d),1:T(d));
%     V=V(:,1:T(d));
    g{d}(1:T(d-1),:,1:T(d))=reshape(U*sqrt(S),T(d-1),I(d),T(d));
    Xn=sqrt(S)*V';
end
% estimate the D-th factor
g{D}(1:T(D-1),:,1)=Xn;
end