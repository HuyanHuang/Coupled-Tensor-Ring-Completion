% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.


function [ZT_1, ZT_2, ZT_3] = tensor_scaled_latent_norm_dual(T,  indT,  beta, lambda1, lambda2, lambda3)

sizeT = size(T);
tdim = ndims(T);

vT = indT;


vT_compl = 1:prod(size(T));
vT_compl(vT) = [];



ZT_1 = zeros(size(T));
ZT_2 = zeros(size(T));
ZT_3 = zeros(size(T));


WT_1 = zeros(size(T));
WT_2 = zeros(size(T));
WT_3 = zeros(size(T));


iter = 0;

ssT = size(T);
sizeTp = prod(ssT);
I_ = zeros(ssT);
I_(vT) = 1;
I_ = reshape(I_ , [sizeTp,1]);
II = diag(sparse(ones(sizeTp,1)));
L = beta*tdim*II + diag(sparse(I_));
T_ =zeros(ssT);
T_(vT) = T(vT);


while true

t_Z = ZT_1 + ZT_2 + ZT_3;
t_W = WT_1 + WT_2 + WT_3;
t_Z(vT_compl) = 0;
t_W(vT_compl) = 0;
RT = reshape(T_ , [sizeTp,1]) - reshape( t_Z ,[sizeTp,1]) +  beta*reshape( t_W,[sizeTp,1])  ;
alpha_T = reshape(L\RT, size(T));


t_alpha_T = alpha_T;
t_alpha_T(vT_compl) = 0;
t_TX = flatten(t_alpha_T,1);
t_Z = flatten(ZT_1,1);
t_TXp = prox_spec_sc(t_TX + t_Z/beta, lambda1/(sqrt(sizeT(1)))  );
WT_1 = flatten_adj(t_TXp(1:end), size(WT_1) , 1);
t_T2 = flatten(t_alpha_T,2);
WT_2 = flatten_adj(prox_spec_sc(t_T2 + flatten(ZT_2,2)/beta, lambda2/(sqrt(sizeT(2)))  ) ,size(WT_2) ,2);
t_T3 = flatten(t_alpha_T,3);
WT_3 = flatten_adj(prox_spec_sc(t_T3 + flatten(ZT_3,3)/beta, lambda3/(sqrt(sizeT(3)))  ) ,size(WT_3) ,3);


% dual variables
ZT_1 = ZT_1 + beta*(t_alpha_T - WT_1);
ZT_2 = ZT_2 + beta*(t_alpha_T - WT_2);
ZT_3 = ZT_3 + beta*(t_alpha_T - WT_3);


iter = iter + 1;

trace_nom_T = (lambda1/sqrt(sizeT(1)))*sum(svd(flatten(ZT_1,1)) ) + (lambda2/sqrt(sizeT(2)))*sum(svd(flatten(ZT_2,2)))  + (lambda3/sqrt(sizeT(3)))*sum(svd(flatten(ZT_3,3)));
primal = ZT_1 + ZT_2 + ZT_3;
obj_primal = 0.5*sum(sum(sum((primal(indT) - T(indT)).^2))) +  trace_nom_T;  %+ (lambda1/sqrt(sizeT(1)))*sum(svd(ZM))


ss1 =  ( 1/pcaspec(flatten(WT_1, 1)/(lambda1/sqrt(sizeT(1))) ,1,10) ) ;
ss2 =  ( 1/pcaspec(flatten(WT_2/(lambda2/sqrt(sizeT(2)))  ,2) , 1 ,10) );
ss3 =  ( 1/pcaspec(flatten(WT_3/(lambda3/sqrt(sizeT(3)))  ,3) , 1 ,10) ) ;
t_alpha_T_scaled  = alpha_T*min([1 , ss1 , ss2 , ss3 ]);

obj_dual = 0.5*norm(t_alpha_T_scaled(:))^2 - sum(sum(sum(t_alpha_T_scaled.*T_))) ;
%abs((obj_primal + obj_dual)/obj_primal);
%iter
if(((iter > 50) && abs((obj_primal + obj_dual)/obj_primal) < 0.001) || iter > 1000 ) % ||  (iter > 30 && norm(st) < 0.005 && norm(st2) < 0.005) ) % norm(M1(:) - X1(:)) < 0.001   && norm(T1(:) - Y1_1(:)) < 0.001  && norm(T1(:) - Y1_2(:)) < 0.001  && norm(T1(:) - Y1_3(:)) < 0.001 ) )
iter
%obj_primal
%obj_dual
%(obj_primal + obj_dual)/obj_primal
break;
end


end


end




