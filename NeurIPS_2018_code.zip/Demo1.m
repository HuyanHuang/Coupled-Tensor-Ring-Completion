%Demo 1 - coupled completion with multilinear rank based tensors
% For coupled norm based on multilinear rank use the code from http://kishan-wimalawarne.com/onewebmedia/NECO-05-17-2859R5-Supplementary_Code.zip. 
dim_tensor = [10,10,10];
rank_tensor = [5,5,5];
dim_matrix = [10,20];
rank_matrix = 5;
shared_rank = 5;
generate_coupled_3_mode_tensor_matrix_multilinear_rank(dim_tensor,rank_tensor, dim_matrix, rank_matrix, shared_rank);

simulation_completion_T_full_M_full('coupled_data.mat', 0.01:10:100,2);
simulation_completion_T_latent_M_full('coupled_data.mat', 0.01:10:100,0.01:10:100,2);
simulation_completion_T_full_M_latent('coupled_data.mat', 0.01:10:100,0.01:10:100,2);
simulation_completion_T_latent_M_latent('coupled_data.mat', 0.01:10:100,0.01:10:100,2);

simulation_completion_Matrix('coupled_data.mat', 0.01:10:100,2);
simulation_completion_Tensor('coupled_data.mat', 0.01:10:100,2);

simulation_completion_overlapped_trace_norm('coupled_data.mat', 0.01:10:100,2);
simulation_completion_latent_trace_norm('coupled_data.mat', 0.01:10:100,2);


plott_matrix(2,360,240,120);
plott_tensor(2,4800,3200,1600);