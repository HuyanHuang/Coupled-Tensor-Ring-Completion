% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function T1 = tensor_overlapped_trace_norm(T, indT, beta, lambda)

sizeT = size(T);

size_modes = ndims(T);

vT = indT;

T1 = zeros(size(T));

for i = 1:size_modes
   Z{i} =  zeros(size(T));
   W{i} =  zeros(size(T)); 
end

iter = 0;

sizeTp = prod(sizeT);
I_ = sparse(sizeTp,1);
I_(vT) = 1;
II = diag(sparse(ones(sizeTp,1)));

while true

sum_W = 0;
sum_Z = 0;
for i =1:size_modes
    sum_W = sum_W + W{i};
    sum_Z = sum_Z + Z{i};
end

T_ =zeros(sizeT);
T_(vT) = T(vT);
r = (diag(I_) + size_modes*beta*II)\( T_(:) - sum_W(:)  + beta*sum_Z(:) ) ;
T1 = reshape( r , sizeT );


% Trace norm 
for i =1:size_modes
t_T = flatten(T1, i);
Z{i} = flatten_adj(prox_nuc(t_T + flatten(W{i}, i)/beta, lambda/beta ) ,sizeT ,i);
end

% dual variables
for i =1:size_modes
  W{i} = W{i} + beta*(T1 - Z{i});  
    
end


iter = iter + 1;

st = 0;
for i =1:size_modes
  st = st + W{i}(vT);  
end
st = st + (T1(vT) - T(vT));
%norm(st)

%norm(M1(:) - X1(:));
%if((iter > 50)  &&  (norm(M1(:) - X1(:)) < 0.001   && norm(T1(:) - Y1_1(:)) < 0.001  && norm(T1(:) - Y1_2(:)) < 0.001  && norm(T1(:) - Y1_3(:)) < 0.001 ) )
if((iter > 700 &&   norm(st) < 0.00001) || iter > 1000)
%iter
%norm(st)

break;
end

end
%iter

end



