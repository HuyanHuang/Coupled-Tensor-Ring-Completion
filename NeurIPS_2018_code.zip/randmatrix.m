% RANDTENSOR3 - Randomly generates a 3-way low-rank tensor
%
% Syntax
%  function X=randtensor3(sz, dims)
%
% Reference
% "On the extension of trace norm to tensors"
% Ryota Tomioka, Kohei Hayashi, and Hisashi Kashima
% arXiv:1010.0789
% http://arxiv.org/abs/1010.0789
% 
% Copyright(c) 2010 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt


function X=randmatrix(sz, dims)

nd=length(sz);

C=randn(dims,1);

U=cell(1,2);
%for jj=1:2
dims(1)
  [U{1},R]=qr(randn(sz(1),dims(1)),0);
  [U{2},R1]=qr(randn(sz(2),dims(1)),0);
%end
U{1}'*U{1};
U{2}'*U{2};
size(U{1});
size(U{2});
X = U{1}*diag(C)*U{2}';

%X=kolda3(C,U{:});
