% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function simulation_completion_overlapped_trace_norm(file_str, reg_parameter,no_of_dataset)

%file_str -  name of the MAT file 
%reg_parameter - regularization parameter
%no_of_dataset - number of data selections

X = load(file_str);

res = zeros(1,20);

for it = 1:no_of_dataset
for j = 1:ssize


Ttr = X.X.train{it}{j}';
Tv = X.X.val{it}{j}';
Tt = X.X.test{it}{j}';

T = X.X.T{it};


pbeta = 1;
lambda = reg_parameter;
spg = size(lambda , 2);

cv = zeros(spg ,1 );


te = cputime;
tic;



parfor i = 1:spg


T1 = tensor_overlapped_trace_norm(T, Ttr,  pbeta, lambda(i));
cv(i,1) =norm(T1(Tv) - T(Tv) );



end

mindx = find(min(cv) == cv);
mindx
cv1{it}{j} = cv;


T1 = tensor_overlapped_trace_norm(T, Ttr,  pbeta, lambda(1,mindx(1,1)));
res(j,it) =  norm(T1(Tt) - T(Tt));



WT{it} = T1;




%sname = strcat('res_overlapped_norm' , num2str(it), num2str(ssize), '.mat');
sname = strcat('res_overlapped_norm' ,  '.mat');
save(sname, 'res');
%sname = strcat('cv_overlapped_norm' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('cv_overlapped_norm' ,  '.mat');
save(sname, 'cv1');
%sname = strcat('WT_overlapped_norm' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('WT_overlapped_norm' ,  '.mat');
save(sname, 'WT');


end
end

%res
%cv

end
