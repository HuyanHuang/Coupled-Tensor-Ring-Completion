% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function [T1,  M1]  = CP_completion_T_full_M_full(T, ind_T, M, ind_M, lambda,opt_option)

sizeT = size(T);
sizeM = size(M);

T1 = rand(sizeT); % coupled
M1 = rand(sizeM); % coupled

ind_Tc = 1:prod(sizeT);
ind_Mc = 1:prod(sizeM);
ind_Tc(ind_T) = [];
ind_Mc(ind_M) = [];

for i = 1:100
    T1_ = -(T - T1);
    M1_ = -(M - M1);
    T1_(ind_Tc) = 0;
    M1_(ind_Mc) = 0;
    
   
    if ndims(T) == 3 && ismatrix(M)
        [Tt, Mt, uc, u2, u3, um, sv1 , sv2] = ApproaxSpectral_3D_1M_mode1(T1_,M1_);
        Tt = -lambda*Tt;
        Mt = -lambda*Mt;
    else
         sprintf('Dimensions missmatch.')    
         return
    end
    
    if(opt_option == 0) % Yuning Yang et al IEEE signal letters 2015
        D1 = Tt - T1;
        D2 = Mt - M1;
        D1_obs = D1;
        D2_obs = D2;
        D1_obs(ind_Tc) = 0;
        D2_obs(ind_Mc) = 0;
        alpha = min(1, abs(D1(:)'*T1_(:) + D2(:)'*M1_(:))/(D1_obs(:)'*D1_obs(:) + D2_obs(:)'*D2_obs(:))  );
        T1 = T1 + alpha*D1;
        M1 = M1 + alpha*D2;
     elseif(opt_option == 1)
        % line search methods to be implmented
     elseif(opt_option == 2)
        %Frank-Wolfe (1956) in Jaggi
        T1 = T1 + (2/(2+ (i-1)))*(Tt - T1);
        M1 = M1 + (2/(2+ (i-1)))*(Mt - M1);
     else
       sprintf('Unspecified line search.') 
       return
     end
    
end

end