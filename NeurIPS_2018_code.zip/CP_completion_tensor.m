% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function T1  = CP_completion_tensor(T, ind_T,  lambda,opt_option)

sizeT = size(T);


T1 = rand(sizeT); 

ind_Tc = 1:prod(sizeT);

ind_Tc(ind_T) = [];

for i = 1:2500
    T1_ = -(T - T1);

    T1_(ind_Tc) = 0;
   
    if ndims(T) == 2
            [Tt, uc, u2,   sv1 ] = ApproaxSpectral_2D(T1_);
    elseif ndims(T) == 3
        %i
            [Tt, uc, u2, u3,  sv1 ] = ApproaxSpectral_3D(T1_);
    else
         sprintf('Dimensions missmatch.')  
         return
    end
    
    % duality gap
    T_diff = (T1 - (-lambda)*Tt);
    T_diff_full = -(T - T1);
    T_diff_full(ind_Tc) = 0;
    d_gap = T_diff(:)'*T_diff_full(:);
    %d_gap
    if abs(d_gap) < 1e-2
        i, d_gap
        break;
    end
    

    if(opt_option == 0) % Yuning Yang et al IEEE signal letters 2015
        Tt = -lambda*Tt;
        D1 = Tt - T1;
        D1_obs = D1;
        D1_obs(ind_Tc) = 0;
        alpha = min(1, abs(D1(:)'*T1_(:) )/(D1_obs(:)'*D1_obs(:) )  );
        T1 = T1 + alpha*D1;
    elseif(opt_option == 1)
        % line search ???? how ???? this seems erronous
        c = 0.2;
        discount = 0.75;
        alpha = 1.0;
        Tt = -lambda*Tt;
        for k = 1:100
           fx = 0.5*norm(T(ind_T) - T1(ind_T))^2;
           tmp_T = T1 + alpha*(Tt - T1);
           fx_step = 0.5*norm(T(ind_T) - tmp_T(ind_T))^2;
           if(fx_step > fx + c*alpha*norm(Tt(:))^2)
               alpha = discount*alpha;
           else
               break;
           end
                         
        end
        alpha
        T1 = T1 + alpha*(Tt - T1);
    elseif(opt_option == 2)
        %Frank-Wolfe (1956) in Jaggi
        Tt = -lambda*Tt;
        T1 = T1 + (2/(2+ (i-1)))*(Tt - T1);
    else
       sprintf('Unspecified line search.') 
       return
    end

    
end

end