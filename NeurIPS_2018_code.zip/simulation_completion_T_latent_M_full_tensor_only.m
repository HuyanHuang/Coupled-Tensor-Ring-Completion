% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function simulation_completion_T_latent_M_full_tensor_only(file_str, reg_parameter1,reg_parameter2,no_of_dataset)


%file_str -  name of the MAT file 
%reg_parameter - regularization parameter
%no_of_dataset - number of data selections

X = load(file_str);

res = zeros(1,20);
res_t = zeros(1,20);

for it = 1:no_of_dataset
for j = 1:ssize


Ttr = X.X.train{it}{j}';
Tv = X.X.val{it}{j}';
Tt = X.X.test{it}{j}';

Mtr = X.X.trainM{it}{j}';


T = X.X.T{it};
M = X.X.M{it};


lambda = reg_parameter1; % exp(linspace(log(0.01), log(5000), 200));
lambda2 = reg_parameter2; % exp(linspace(log(0.01), log(5000), 200));

spg = size(lambda , 2);
spg2 = size(lambda2 , 2);
cv = zeros(spg ,spg2 );


for i = 1:spg
    parfor k = 1:spg2

[T1, T2,  M1]  = CP_completion_T_latent_M_full(T, Ttr, M, Mtr, lambda(i+150) , lambda2(k+155),2);
T_1 = T1 +T2;
cv(i,k) =norm(T_1(Tv) - T(Tv)) ;

    end
end

% Selecting the best regularization paramter
[mindx1, mindx2]= find(min(min(cv)) == cv);
sprintf('Best regularization parameters : %f, %f', lambda(1,mindx1), lambda2(1,mindx2));
cv1{it}{j} = cv;

[T1, T2, M1]  = CP_completion_T_latent_M_full(T, Ttr, M, Mtr, lambda(1,mindx1+150) , lambda2(1,mindx2+155),2);
T_1 = T1 +T2;
res(j,it) = norm(T_1(Tt) - T(Tt)) ;
res_t(j,it) = norm(T_1(Tt) - T(Tt)) ;

WT{it}{1} = T1;
WT{it}{2} = T2;
WM{it} = M1;




%sname = strcat('res_ccp_latent_full_T' , num2str(it), num2str(ssize), '.mat');
sname = strcat('res_ccp_latent_full_T' ,  '.mat');
save(sname, 'res_t');
%sname = strcat('cv_ccp_latent_full_T' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('cv_ccp_latent_full_T' ,  '.mat');
save(sname, 'cv1');
%sname = strcat('WT_ccp_latent_full_T' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('WT_ccp_latent_full_T' ,  '.mat');
save(sname, 'WT');
%sname = strcat('WM_ccp_latent_full_T' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('WM_ccp_latent_full_T' ,  '.mat');
save(sname, 'WM');


end
end

%res
%cv

end
