% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

function plott_tensor(no_datasets,test_size1,test_size2,test_size3)


a1 = load('res_overlapped_norm.mat');
a2 = load('res_scaled_latent.mat');
%a3 = load('res_coupled_norm.mat'); % use the results from coupled norms with
%multinear ranks.
a4 = load('res_CP_tensor.mat');
a5 = load('res_ccp_full_full_T.mat');
a6 = load('res_ccp_latent_full_T.mat');
a7 = load('res_ccp_full_latent_T.mat');



a1.res(1,:) = a1.res(1,:)/sqrt(test_size1); 
a1.res(2,:) = a1.res(2,:)/sqrt(test_size2); 
a1.res(3,:) = a1.res(3,:)/sqrt(test_size3); 

a2.res(1,:) = a2.res(1,:)/sqrt(test_size1); 
a2.res(2,:) = a2.res(2,:)/sqrt(test_size2); 
a2.res(3,:) = a2.res(3,:)/sqrt(test_size3); 

% a3.res(1,:) = a3.res_t(1,:)/sqrt(test_size1); 
% a3.res(2,:) = a3.res_t(2,:)/sqrt(test_size2); 
% a3.res(3,:) = a3.res_t(3,:)/sqrt(test_size3); 

a4.res(1,:) = a4.res_t(1,:)/sqrt(test_size1); 
a4.res(2,:) = a4.res_t(2,:)/sqrt(test_size2); 
a4.res(3,:) = a4.res_t(3,:)/sqrt(test_size3); 

a5.res(1,:) = a5.res_t(1,:)/sqrt(test_size1); 
a5.res(2,:) = a5.res_t(2,:)/sqrt(test_size2); 
a5.res(3,:) = a5.res_t(3,:)/sqrt(test_size3); 

a6.res(1,:) = a6.res_t(1,:)/sqrt(test_size1); 
a6.res(2,:) = a6.res_t(2,:)/sqrt(test_size2); 
a6.res(3,:) = a6.res_t(3,:)/sqrt(test_size3); 

a7.res(1,:) = a7.res_t(1,:)/sqrt(test_size1); 
a7.res(2,:) = a7.res_t(2,:)/sqrt(test_size2); 
a7.res(3,:) = a7.res_t(3,:)/sqrt(test_size3); 

am1(1,1) = mean(a1.res(1,1:no_datasets));
as1(1,1) = std(a1.res(1,1:no_datasets));
am1(1,2) = mean(a1.res(2,1:no_datasets));
as1(1,2) = std(a1.res(2,1:no_datasets));
am1(1,3) = mean(a1.res(3,1:no_datasets));
as1(1,3) = std(a1.res(3,1:no_datasets));

am2(1,1) = mean(a2.res(1,1:no_datasets));
as2(1,1) = std(a2.res(1,1:no_datasets));
am2(1,2) = mean(a2.res(2,1:no_datasets));
as2(1,2) = std(a2.res(2,1:no_datasets));
am2(1,3) = mean(a2.res(3,1:no_datasets));
as2(1,3) = std(a2.res(3,1:no_datasets));


% am3(1,1) = mean(a3.res(1,1:no_datasets));
% as3(1,1) = std(a3.res(1,1:no_datasets));
% am3(1,2) = mean(a3.res(2,1:no_datasets));
% as3(1,2) = std(a3.res(2,1:no_datasets));
% am3(1,3) = mean(a3.res(3,1:no_datasets));
% as3(1,3) = std(a3.res(3,1:no_datasets));

am4(1,1) = mean(a4.res(1,1:no_datasets));
as4(1,1) = std(a4.res(1,1:no_datasets));
am4(1,2) = mean(a4.res(2,1:no_datasets));
as4(1,2) = std(a4.res(2,1:no_datasets));
am4(1,3) = mean(a4.res(3,1:no_datasets));
as4(1,3) = std(a4.res(3,1:no_datasets));

am5(1,1) = mean(a5.res(1,1:no_datasets));
as5(1,1) = std(a5.res(1,1:no_datasets));
am5(1,2) = mean(a5.res(2,1:no_datasets));
as5(1,2) = std(a5.res(2,1:no_datasets));
am5(1,3) = mean(a5.res(3,1:no_datasets));
as5(1,3) = std(a5.res(3,1:no_datasets));

am6(1,1) = mean(a6.res(1,1:no_datasets));
as6(1,1) = std(a6.res(1,1:no_datasets));
am6(1,2) = mean(a6.res(2,1:no_datasets));
as6(1,2) = std(a6.res(2,1:no_datasets));
am6(1,3) = mean(a6.res(3,1:no_datasets));
as6(1,3) = std(a6.res(3,1:no_datasets));

am7(1,1) = mean(a7.res(1,1:no_datasets));
as7(1,1) = std(a7.res(1,1:no_datasets));
am7(1,2) = mean(a7.res(2,1:no_datasets));
as7(1,2) = std(a7.res(2,1:no_datasets));
am7(1,3) = mean(a7.res(3,1:no_datasets));
as7(1,3) = std(a7.res(3,1:no_datasets));


X = [ 0.3 0.5 0.7];

hold on
grid on;

%check the legends....
h = errorbar(X,am1,as1,'-.r*', 'LineWidth',2);
h = errorbar(X,am2,as2,'-.k', 'LineWidth',2);
%h = errorbar(X,am3,as3,'-.mo', 'LineWidth',2);
h = errorbar(X,am4,as4,':b<', 'LineWidth',2);
h = errorbar(X,am5,as5,':h', 'LineWidth',2);
h = errorbar(X,am6,as6,'--+c', 'LineWidth',2);
h = errorbar(X,am7,as7,':g', 'LineWidth',2);


set(gca,'FontSize',14);

xlabel('Fraction of training samples');  
ylabel('MSE');
%legend('OTN' , 'SLTN' , '(O,O,O)' , 'TNN' , 'ccp-1' , 'ccp-2', 'ccp-3'    );
legend('OTN' , 'SLTN' ,  'TNN' , 'ccp-1' , 'ccp-2', 'ccp-3'    );
legend('Location' , 'NorthEast');

print -depsc tensor

hold off;

end
