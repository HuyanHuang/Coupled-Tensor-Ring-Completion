% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function simulation_completion_Matrix(file_str, reg_parameter,no_of_dataset)

%file_str -  name of the MAT file 
%reg_parameter - regularization parameter
%no_of_dataset - number of data selections

ssize = 3;

X = load(file_str);

res_m = zeros(1,20);

for it = 1:no_of_dataset
for j = 1:ssize


Ttr = X.X.trainM{it}{j}';
Tv = X.X.valM{it}{j}';
Tt = X.X.testM{it}{j}';

T = X.X.M{it};


lambda = reg_parameter; %0.01:1:100 

spg = size(lambda , 2);

cv = zeros(spg ,1 );


parfor i = 1:spg

T1 = CP_completion_tensor(T, Ttr, lambda(i),1);
cv(i,1) =norm(T1(Tv) - T(Tv));

end

% Selecting the best regularization paramter
mindx = find(min(cv) == cv);
sprintf('Best regularization parameter : %f', lambda(1,mindx(1,1)));
cv1{it}{j} = cv;

T1 = CP_completion_tensor(T, Ttr, lambda(1,mindx(1,1)),2);
res_m(j,it) = norm(T1(Tt) - T(Tt)) ;

WZ{it} = T1;


%sname = strcat('res_matrix' , num2str(it), num2str(ssize), '.mat');
sname = strcat('res_matrix' ,  '.mat');
save(sname, 'res_m');
%sname = strcat('cv_matrix' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('cv_matrix' ,  '.mat');
save(sname, 'cv1');
%sname = strcat('WZ_matrix' , num2str(it), num2str(ssize)  , '.mat');
sname = strcat('WZ_matrix' ,  '.mat');
save(sname, 'WZ');

end
end


end
