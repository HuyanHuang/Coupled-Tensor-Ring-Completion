function [model,x0]=init_tensor_ring(model)
% initilize tensor ring
val=model.val;
idx=model.idx;
siz=model.siz;
TRr=model.TRr;
method=model.int;
N=length(model.val);
% x0=cellfun(@initialization_M,siz,idx,val,'UniformOutput',false);
x0=cell(1,N);
for n=1:N
    x0{n}=nan(siz{n});
    x0{n}(idx{n})=val{n};
    x0{n}=reshape(fillmissing(x0{n}(:),'pchip'),siz{n});
end
[x0,model.fct]=cellfun(@TR_init,siz,TRr,method,x0,'UniformOutput',false);
model.grd=model.fct;
end