clc
clear
close all
%% input arguments
TRr1=2:2:14;
TRr2=2:2:14;
CPr1=2:2:14;
CPr2=2:2:14;
num_trial=5;
SR={0.5,0.5};
load('/Users/huanghuyan/Documents/MATLAB/Dataset/Coupled data/E_nose_data.mat')
good=NoseData.data(1:6,2:end,:);
good=permute(good,[2 3 1]);
bad=NoseData.data(7:12,2:end,:);
bad=permute(bad,[2 3 1]);
%% ket augmentation--covert original(low-order) tensor to high-order tensor
% tensor #1
siz1=size(good);
I1=[6 3 4 4 5 3 4];
order1=[2:length(I1) 1];
J1=I1;
tnsr1=l2h(good,I1,order1,J1);
% tensor #2
siz2=size(bad);
I2=[6 3 4 4 5 3 4];
order2=[2:length(I2) 1];
J2=I2;
tnsr2=l2h(bad,I2,order2,J2);
%% trial
% RMSE_CTR=zeros(num_trial,length(TRr1),2);
% RMSE_TR=zeros(num_trial,length(TRr1),2);
% RMSE_CNN=zeros(num_trial,length(TRr1),2);
% RMSE_ACMTF=zeros(num_trial,length(CPr1),2);
% RMSE_SDF=zeros(num_trial,length(CPr2),2);
% 
% time_CTR=zeros(num_trial,length(TRr1));
% time_TR=zeros(num_trial,length(TRr1),2);
% time_CNN=zeros(num_trial,length(TRr1));
% time_ACMTF=zeros(num_trial,length(CPr1));
% time_SDF=zeros(num_trial,length(CPr2));
load recovery_Licorice
for h=1:num_trial
    % sampling
    model.gdt={tnsr1,tnsr2};
    [model.val,model.idx]=cellfun(@unisam,model.gdt,SR,'UniformOutput',false);
%     % CTR
%     L=6;
%     model.siz=cellfun(@size,model.gdt,'UniformOutput',false);
%     D=cellfun(@length,model.siz);
%     model.dim={[1:L,L+1:D(1)],[1:L,D(1)+1:sum(D)-L]};
%     warning off
%     for k=1:length(TRr1)
%         model.TRr={TRr1(k)*ones(1,D(1)),TRr2(k)*ones(1,D(2))};
%         for i=1:length(model.gdt)
%             model.tau{i}=zeros(D(i),2);
%             model.tau{i}(1:L,:)=min(TRr1(k),TRr2(k));
%         end        
%         [x,RC,RMSE,time_CTR(h,k)]=CTR_ALS(model,false);
%         [~,I]=min(sum(RMSE,2));
%         RMSE_CTR(h,k,:)=RMSE(I,:);
%         fprintf('TR rank=%d,RMSE=%f\t%f\n',TRr1(k),RMSE_CTR(h,k,1),RMSE_CTR(h,k,2));
%     end
%     fprintf('===========================================================\n');
%     % TR
%     for k=1:length(TRr1)
%         for i=1:length(model.gdt)
%             model1.val=model.val{i};
%             model1.idx=model.idx{i};
%             model1.siz=model.siz{i};
%             model1.TRr=TRr1(k)*ones(1,D(i));
%             model1.gdt=model.gdt{i};
%             [x1,RC,RMSE,time_TR(h,k,i)]=TR_FastALS(model1,false);
%             if i==1
%                 RMSE_TR(h,k,1)=min(RMSE);
%                 fprintf('TR rank=%d,RMSE=%f\n',TRr1(k),RMSE_TR(h,k,1));
%             else
%                 RMSE_TR(h,k,2)=min(RMSE);
%                 fprintf('RMSE=%f\n',RMSE_TR(h,k,2));
%             end
%         end
%     end
%     warning on
%     fprintf('===========================================================\n');
%     % CNN
%     t=cputime;
%     [T1,M1]=CP_completion_T_full_M_full(good,model.idx{1},bad,model.idx{2},1,2);
%     time_CNN(h,k)=cputime-t;
%     RMSE_CNN(h,:,:)=repmat([rmse(T1,model.gdt{1}),rmse(M1,model.gdt{2})],7,1);
%     fprintf('running time=%fs\n',time_CNN(h,k));
%     fprintf('CP rank=-,RMSE=%f\t%f\n',RMSE_CNN(h,1,1),RMSE_CNN(h,1,2));
%     fprintf('===========================================================\n');
%     % ACMTF
%     options1 = ncg('defaults');
%     options1.Display ='iter';
%     options1.MaxFuncEvals = 100000;
%     options1.MaxIters     = 500;
%     options1.StopTol      = 1e-8;
%     options1.RelFuncTol   = 1e-8;
%     Z.modes={1:3,[1:2 4]};
%     Z.size=[240 12 6 6];
%     
%     Z.miss{1}=zeros(size(good));
%     Z.miss{1}(model.idx{1})=1;
%     Z.object{1}=tensor(Z.miss{1}.*good);
%     Z.miss{1}=tensor(Z.miss{1});
%     
%     Z.miss{2}=zeros(size(bad));
%     Z.miss{2}(model.idx{2})=1;
%     Z.object{2}=tensor(Z.miss{2}.*bad);
%     Z.miss{2}=tensor(Z.miss{2});
%     for k=1:length(CPr1)
%         t=cputime;
%         [Zhat,Init]=acmtf_opt(Z,CPr1(k),'init','random','alg_options',options1,'beta_cp',0,'beta_pca',0);
%         time_ACMTF(h,k)=cputime-t;
%         fprintf('running time=%fs\n',time_ACMTF(h,k));
%         data=cell(1,length(model.gdt));
%         for i=1:length(model.gdt)
%             data{i}=full(Zhat{i});
%             if i==1
%                 RMSE_ACMTF(h,k,1)=rmse(data{i},good);
%                 fprintf('CP rank=%d,RMSE=%f\t',CPr1(k),RMSE_ACMTF(h,k,1));
%             else
%                 RMSE_ACMTF(h,k,2)=rmse(data{i},bad);
%                 fprintf('%f\n',RMSE_ACMTF(h,k,2));
%             end
%         end
%     end
%     fprintf('===========================================================\n');
    % SDF
    constr = {}; % try {@struct_nonneg} or {@struct_sigmoid};
    % Define the factor matrices
    model2.factors.U   = cat(2,'u',constr);
    model2.factors.L   = cat(2,'l',constr);
    model2.factors.A1   = cat(2,'a1',constr);
    model2.factors.A2   = cat(2,'a2',constr);
    UserLocAct_missing = good;
    UserLocAct_missing(model.idx{1}) = nan;
    UserLocAct_missing = fmt(UserLocAct_missing);
    
    UserLoc_missing = bad;
    UserLoc_missing(model.idx{2}) = nan;
    UserLoc_missing = fmt(UserLoc_missing);
    
    model2.factorizations.ula1.data = UserLocAct_missing;
    model2.factorizations.ula1.cpd  = {'U','L','A1'};
    model2.factorizations.ula2.data = UserLoc_missing;
    model2.factorizations.ula2.cpd  = {'U','L','A2'};
    
    % Add regularization
    model2.factorizations.reg.regL2 = {'U','L','A1','A2'};
    lambda1 = 0.005;
    lambda2 = 0.005;
    lambda3 = 0.005;
    lambda4 = 0.005;
    lambdareg = 1e-6;
    options2.Display    = 10;
    options2.MaxIter    = 500;
    options2.TolFun     = 0;
    options2.TolX       = 1e-15;
    options2.RelWeights = [1 lambda1 lambda2 lambda3 lambda4];
    for k=1:length(CPr2)
        % Define all variables
        model2.variables.u   = rand(size(good, 1),CPr2(k));
        model2.variables.l   = rand(size(good, 2),CPr2(k));
        model2.variables.a1   = rand(size(good, 3),CPr2(k));
        model2.variables.a2   = rand(size(bad, 3),CPr2(k));
        t=cputime;
        [sol,out] = sdf_nls(model2,options2);
        time_SDF(h,k)=cputime-t;
        fprintf('running time=%fs\n',time_SDF(h,k));
        T2 = cpdgen({sol.factors.U,sol.factors.L,sol.factors.A1});
        M2 = cpdgen({sol.factors.U,sol.factors.L,sol.factors.A2});
        RMSE_SDF(h,k,:)=[rmse(T2,model.gdt{1}),rmse(M2,model.gdt{2})];
        fprintf('CP rank=%d,RMSE=%f\t%f\n',CPr2(k),RMSE_SDF(h,k,1),RMSE_SDF(h,k,2));
    end
    fprintf('===========================================================\n');
end
%% save
recovery_Licorice.method{1}='CTR';
recovery_Licorice.RMSE{1}=RMSE_CTR;
recovery_Licorice.runtime{1}=time_CTR;

recovery_Licorice.method{2}='TR';
recovery_Licorice.RMSE{2}=RMSE_TR;
recovery_Licorice.runtime{2}=time_TR;

recovery_Licorice.method{3}='CNN';
recovery_Licorice.RMSE{3}=RMSE_CNN;
recovery_Licorice.runtime{3}=time_CNN;

recovery_Licorice.method{4}='ACMTF';
recovery_Licorice.RMSE{4}=RMSE_ACMTF;
recovery_Licorice.runtime{4}=time_ACMTF;

recovery_Licorice.method{5}='SDF';
recovery_Licorice.RMSE{5}=RMSE_SDF;
recovery_Licorice.runtime{5}=time_SDF;
save recovery_Licorice recovery_Licorice
%% manipulation
RMSE_c=cellfun(@mean,recovery_Licorice.RMSE,'UniformOutput',false);
RMSE_c=cellfun(@squeeze,RMSE_c,'UniformOutput',false);
runtime_c=cellfun(@mean,recovery_Licorice.runtime,'UniformOutput',false);
runtime_c=cellfun(@squeeze,runtime_c,'UniformOutput',false);
%% visualization
figure;
subplot(2,1,1);
hold on
p=plot(TRr1,log10([RMSE_c{1}(:,1),RMSE_c{2}(:,1),RMSE_c{4}(:,1),RMSE_c{5}(:,1)]));
p(1).Marker='p';
p(2).Marker='o';
p(3).Marker='+';
p(4).Marker='^';
xlabel('Tensor rank');
ylabel('RMSE (log_{10})');
legend('CTR','TR','ACMTF','SDF','location','best','box','off');
title('Good licorice');

subplot(2,1,2);
hold on
p=plot(TRr1,log10([RMSE_c{1}(:,2),RMSE_c{2}(:,2),RMSE_c{4}(:,2),RMSE_c{5}(:,2)]));
p(1).Marker='p';
p(2).Marker='o';
p(3).Marker='+';
p(4).Marker='^';
xlabel('Tensor rank');
ylabel('RMSE (log_{10})');
legend('CTR','TR','ACMTF','SDF','location','best','box','off');
title('Bad licorice');

figure;
yyaxis left
hold on
p=plot(TRr1,[runtime_c{1}',sum(runtime_c{2},2),runtime_c{5}']);
p(1).Marker='p';
p(2).Marker='o';
p(3).Marker='^';
xlabel('Tensor rank');
ylabel('CPU time (s)');
yyaxis right
p=plot(TRr1,runtime_c{4}');
p.Marker='+';
ylabel('CPU time (s)');
legend('CTR','TR_T+TR_M','ACMTF','SDF','location','best','box','off');