function [cpd,ucpd,C,ind,P]=init_temp_para(model)
% initilize temporary parameters
val=model.val;
idx=model.idx;
dim=model.dim;
siz=model.siz;
TRr=model.TRr;
tau=model.tau;
D=cellfun(@length,siz);
N=length(model.val);
% tab is a matrix of size L x N,
% the (l,n)-th entry means the n-th TR owns the l-th dimension.
L=max(cell2mat(dim));
tab=zeros(L,N);
for n=1:N
    tab(dim{n},n)=1;
end
% cpd is a cell of size L,
% the l-th entry is the index set of TR corresponding to the l-th dimension.
cpd=cell(1,L);
% ucpd is a cell of size N,
% the n-th entry is the index set of uncoupled dimensions of n-th TR.
ucpd=cell(1,N);
index=sum(tab,2)>1;
for l=1:L
    if index(l)
        cpd{l}=find(tab(l,:)==1);
    else
        ucpd{tab(l,:)==1}=[ucpd{tab(l,:)==1},l];
    end
end
C=cell(1,N);
ind=cell(1,N);
for n=1:N
    W=zeros(siz{n});
    W(idx{n})=1;
    T=W.*reshape(1:prod(siz{n}),siz{n});
    for d=1:D(n)
        Wd=reshape(permute(W,[d d+1:D(n) 1:d-1]),siz{n}(d),[]);
        Td=reshape(permute(T,[d d+1:D(n) 1:d-1]),siz{n}(d),[]);
        for id=1:siz{n}(d)
            ind{n}{d}{id}=find(Wd(id,:));
            [~,~,v]=find(Td(id,:));
            [~,loc]=ismember(v,idx{n});
            C{n}{d}{id}=val{n}(loc)';
        end
    end
end
P=cell(L,N);
for l=1:L
    if ~isempty(cpd{l})
        for n=cpd{l}
            d=find(dim{n}==l);
            vind=1:TRr{n}(d)*TRr{n}(d*(d~=D(n))+1*(d==D(n)));
            P1=reshape(vind,[],TRr{n}(d));
            P1=reshape(P1(1:tau{n}(d,2),1:tau{n}(d,1)),1,[]);
            P2=setdiff(vind,P1);
            P{l,n}={P1,P2};
        end
    end
end
end