function model=vec2tensor_ring(z,model,cpd,ucpd,Len)
x=z(1:Len);
y=z(Len+1:end);
D=cellfun(@length,model.siz);
L=max(cell2mat(model.dim));
N=length(model.val);
num0=0;
num1=0;
for n=1:N
    if ~isempty(ucpd{n})
        siz=model.siz{n}.*[model.TRr{n}(1:end-1).*model.TRr{n}(2:end),model.TRr{n}(1)*model.TRr{n}(end)];
        [~,ds]=ismember(ucpd{n},model.dim{n});
        for d=ds
            num1=num1+siz(d);
            model.fct{n}{d}=reshape(x(num0+1:num1),[model.TRr{n}(d),model.siz{n}(d),model.TRr{n}(d*(d~=D(n))+1*(d==D(n)))]);
            num0=num1;
        end
    end
end
num0=0;
num1=0;
for l=1:L
    if ~isempty(cpd{l})
        ns=cpd{l};
        ds=zeros(1,N);
        for n=ns
            ds(n)=find(model.dim{n}==l);
        end
        ds(ds==0)=[];
        siz=model.siz{n}(ds(end))*model.TRr{n}(ds(end))*model.TRr{n}(ds(end)*(ds(end)~=D(n))+1*(ds(end)==D(n)));
        num1=num1+siz;
        for i=1:length(ds)
            model.fct{ns(i)}{ds(i)}=reshape(y(num0+1:num1),[model.TRr{ns(i)}(ds(i)),model.siz{ns(i)}(ds(i)),model.TRr{ns(i)}(ds(i)*(ds(i)~=D(ns(i)))+1*(ds(i)==D(ns(i))))]);
        end
        num0=num1;
    end
end
end