function [val,idx]=unisam(tnsr,SR)
%% calculate the total number of tnsr
num=numel(tnsr);
%% uniformly random sampling
idx=randsample(num,ceil(SR*num));
idx=sort(idx);
val=tnsr(idx);
end