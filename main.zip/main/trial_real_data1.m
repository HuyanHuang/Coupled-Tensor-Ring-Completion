clc
clear
close all
%% input arguments
TRr1=2:2:14;
TRr2=2:2:14;
CPr1=2:2:14;
CPr2=2:2:14;
num_trial=5;
SR={0.5,0.5};
load aaai10_uclaf_data
load recovery_UCLAF
%% preproceed the dataset
% Use only the link activity.
UserLocAct(UserLocAct>0)=1;
% Remove users with no data.
u=any(any(UserLocAct,2),3);
UserLocAct=UserLocAct(u,:,:);
UserLoc=UserLoc(u,:);
UserUser=UserUser(u,u);
% Replace zero value
UserLocAct(UserLocAct==0)=0.01;
UserLoc(UserLoc==0)=0.01;
UserLocAct([44,146],:,:)=[];
UserLoc([44,146],:)=[];
%% ket augmentation--covert original(low-order) tensor to high-order tensor
% tensor #1
siz1=size(UserLocAct);
I1=[4 6 6 4 6 7 5];
% I1=[144,168,5];
order1=1:length(I1);
J1=I1;
tnsr1=l2h(UserLocAct,I1,order1,J1);
% tensor #2
siz2=size(UserLoc);
I2=[4 6 6 4 6 7];
% I2=[144,168];
order2=1:length(I2);
J2=I2;
tnsr2=l2h(UserLoc,I2,order2,J2);
%% trial
% RMSE_CTR=zeros(num_trial,length(TRr1),2);
% RMSE_TR=zeros(num_trial,length(TRr1),2);
% RMSE_CNN=zeros(num_trial,length(TRr1),2);
% RMSE_ACMTF=zeros(num_trial,length(CPr1),2);
% RMSE_SDF=zeros(num_trial,length(CPr2),2);
% 
% time_CTR=zeros(num_trial,length(TRr1));
% time_TR=zeros(num_trial,length(TRr1),2);
% time_CNN=zeros(num_trial,length(TRr1));
% time_ACMTF=zeros(num_trial,length(CPr1));
% time_SDF=zeros(num_trial,length(CPr2));
load recovery_UCLAF
for h=1:num_trial
    % sampling
    model.gdt={tnsr1,tnsr2};
    [model.val,model.idx]=cellfun(@unisam,model.gdt,SR,'UniformOutput',false);
    % CTR
    L=3;
    model.siz=cellfun(@size,model.gdt,'UniformOutput',false);
    D=cellfun(@length,model.siz);
    model.dim={[1:L,L+1:D(1)],[1:L,D(1)+1:sum(D)-L]};
    for k=1:length(TRr1)
        model.TRr={TRr1(k)*ones(1,D(1)),TRr2(k)*ones(1,D(2))};
        for i=1:length(model.gdt)
            model.tau{i}=zeros(D(i),2);
            model.tau{i}(1:L,:)=min(TRr1(k),TRr2(k));
        end
        [x,RC,RMSE,time_CTR(h,k)]=CTR_ALS(model,false);
        [~,I]=min(sum(RMSE,2));
        RMSE_CTR(h,k,:)=RMSE(I,:);
        fprintf('TR rank=%d,RMSE=%f\t%f\n',TRr1(k),RMSE_CTR(h,k,1),RMSE_CTR(h,k,2));
    end
    fprintf('===========================================================\n');
%     % TR
%     for k=1:length(TRr1)
%         for i=1:length(model.gdt)
%             model1.val=model.val{i};
%             model1.idx=model.idx{i};
%             model1.siz=model.siz{i};
%             model1.TRr=TRr1(k)*ones(1,D(i));
%             model1.gdt=model.gdt{i};
%             [x1,RC,RMSE,time_TR(h,k,i)]=TR_FastALS(model1,false);
%             if i==1
%                 RMSE_TR(h,k,1)=min(RMSE);
%                 fprintf('TR rank=%d,RMSE=%f\n',TRr1(k),RMSE_TR(h,k,1));
%             else
%                 RMSE_TR(h,k,2)=min(RMSE);
%                 fprintf('RMSE=%f\n',RMSE_TR(h,k,2));
%             end
%         end
%     end
%     fprintf('===========================================================\n');
%     % CNN
%     t=cputime;
%     [T1,M1]=CP_completion_T_full_M_full(UserLocAct,model.idx{1},UserLoc,model.idx{2},1,2);
%     time_CNN(h,k)=cputime-t;
%     RMSE_CNN(h,:,:)=repmat([rmse(T1,model.gdt{1}),rmse(M1,model.gdt{2})],7,1);
%     fprintf('running time=%fs\n',time_CNN(h,k));
%     fprintf('CP rank=-,RMSE=%f\t%f\n',RMSE_CNN(h,1,1),RMSE_CNN(h,1,2));
%     fprintf('===========================================================\n');
%     % ACMTF
%     options1 = ncg('defaults');
%     options1.Display ='final';
%     options1.MaxFuncEvals = 100000;
%     options1.MaxIters     = 100;
%     options1.StopTol      = 1e-8;
%     options1.RelFuncTol   = 1e-8;
%     Z.modes={1:3,[1,4]};
%     Z.size=[144 168 5 168];
%     
%     Z.miss{1}=zeros(size(UserLocAct));
%     Z.miss{1}(model.idx{1})=1;
%     Z.object{1}=tensor(Z.miss{1}.*UserLocAct);
%     Z.miss{1}=tensor(Z.miss{1});
%     
%     Z.miss{2}=zeros(size(UserLoc));
%     Z.miss{2}(model.idx{2})=1;
%     Z.object{2}=tensor(Z.miss{2}.*UserLoc);
%     Z.miss{2}=tensor(Z.miss{2});
%     for k=1:length(CPr1)
%         t=cputime;
%         [Zhat,Init]=acmtf_opt(Z,CPr1(k),'init','random','alg_options',options1,'beta_cp',0,'beta_pca',0);
%         time_ACMTF(h,k)=cputime-t;
%         fprintf('running time=%fs\n',time_ACMTF(h,k));
%         data=cell(1,length(model.gdt));
%         for i=1:length(model.gdt)
%             data{i}=full(Zhat{i});
%             if i==1
%                 RMSE_ACMTF(h,k,1)=rmse(data{i},UserLocAct);
%                 fprintf('CP rank=%d,RMSE=%f\t',CPr1(k),RMSE_ACMTF(h,k,1));
%             else
%                 RMSE_ACMTF(h,k,2)=rmse(data{i},UserLoc);
%                 fprintf('%f\n',RMSE_ACMTF(h,k,2));
%             end
%         end
%     end
%     fprintf('===========================================================\n');
%     % SDF
%     constr = {}; % try {@struct_nonneg} or {@struct_sigmoid};
%     % Define the factor matrices
%     model2.factors.U   = cat(2,'u',constr);
%     model2.factors.L   = cat(2,'l',constr);
%     model2.factors.A   = cat(2,'a',constr);
%     model2.factors.Dul = cat(2,'dul',constr);
%     UserLocAct_missing = UserLocAct;
%     UserLocAct_missing(model.idx{1}) = nan;
%     UserLocAct_missing = fmt(UserLocAct_missing);
%     
%     UserLoc_missing = UserLoc;
%     UserLoc_missing(model.idx{2}) = nan;
%     UserLoc_missing = fmt(UserLoc_missing);
%     
%     model2.factorizations.ula.data = UserLocAct_missing;
%     model2.factorizations.ula.cpd  = {'U','L','A'};
%     model2.factorizations.ul.data = UserLoc_missing;
%     model2.factorizations.ul.cpd  = {'U','L','Dul'};
%     
%     % Add regularization
%     model2.factorizations.reg.regL2 = {'U','L','A','Dul'};
%     lambda1 = 0.005;
%     lambda2 = 0.001;
%     lambda3 = 0.005;
%     lambda4 = 0.0001;
%     lambdareg = 1e-6;
%     options2.Display    = 100;
%     options2.MaxIter    = 100;
%     options2.TolFun     = 0;
%     options2.TolX       = 1e-15;
%     options2.RelWeights = [1 lambda1 lambda2 lambda3 lambda4];
%     for k=1:length(CPr2)
%         % Define all variables
%         model2.variables.u   = rand(size(UserLocAct, 1),CPr2(k));
%         model2.variables.l   = rand(size(UserLocAct, 2),CPr2(k));
%         model2.variables.a   = rand(size(UserLocAct, 3),CPr2(k));
%         model2.variables.dul = rand(1,CPr2(k));
%         t=cputime;
%         [sol,out] = sdf_nls(model2,options2);
%         time_SDF(h,k)=cputime-t;
%         fprintf('running time=%fs\n',time_SDF(h,k));
%         T2 = cpdgen({sol.factors.U,sol.factors.L,sol.factors.A});
%         M2 = cpdgen({sol.factors.U,sol.factors.L,sol.factors.Dul});
%         RMSE_SDF(h,k,:)=[rmse(T2,model.gdt{1}),rmse(M2,model.gdt{2})];
%         fprintf('CP rank=%d,RMSE=%f\t%f\n',CPr2(k),RMSE_SDF(h,k,1),RMSE_SDF(h,k,2));
%     end
%     fprintf('===========================================================\n');
end
%% save
recovery_UCLAF.method{1}='CTR';
recovery_UCLAF.RMSE{1}=RMSE_CTR;
recovery_UCLAF.runtime{1}=time_CTR;

recovery_UCLAF.method{2}='TR';
recovery_UCLAF.RMSE{2}=RMSE_TR;
recovery_UCLAF.runtime{2}=time_TR;

recovery_UCLAF.method{3}='CNN';
recovery_UCLAF.RMSE{3}=RMSE_CNN;
recovery_UCLAF.runtime{3}=time_CNN;

recovery_UCLAF.method{4}='ACMTF';
recovery_UCLAF.RMSE{4}=RMSE_ACMTF;
recovery_UCLAF.runtime{4}=time_ACMTF;

recovery_UCLAF.method{5}='SDF';
recovery_UCLAF.RMSE{5}=RMSE_SDF;
recovery_UCLAF.runtime{5}=time_SDF;
save recovery_UCLAF recovery_UCLAF
%% manipulation
RMSE_c=cellfun(@mean,recovery_UCLAF.RMSE,'UniformOutput',false);
RMSE_c=cellfun(@squeeze,RMSE_c,'UniformOutput',false);
runtime_c=cellfun(@mean,recovery_UCLAF.runtime,'UniformOutput',false);
runtime_c=cellfun(@squeeze,runtime_c,'UniformOutput',false);
%% visualization
figure;
subplot(2,1,1);
yyaxis left
hold on
p=plot(TRr1,[RMSE_c{1}(:,1),RMSE_c{2}(:,1),RMSE_c{3}(:,1),RMSE_c{5}(:,1)]);
p(1).Marker='p';
p(2).Marker='o';
p(3).Marker='s';
p(4).Marker='^';
xlabel('Tensor rank');
ylabel('RMSE');
yyaxis right
p=plot(TRr1,RMSE_c{4}(:,1));
p(1).Marker='+';
ylabel('RMSE');
legend('CTR','TR','CNN','SDF','ACMTF','location','best','box','off');
title('User-Loc-Act tensor');
subplot(2,1,2);
yyaxis left
hold on
p=plot(TRr1,[RMSE_c{1}(:,2),RMSE_c{2}(:,2),RMSE_c{3}(:,2),RMSE_c{5}(:,2)]);
p(1).Marker='p';
p(2).Marker='o';
p(3).Marker='s';
p(4).Marker='^';
xlabel('Tensor rank');
ylabel('RMSE');
yyaxis right
p=plot(TRr1,RMSE_c{4}(:,2));
p(1).Marker='+';
ylabel('RMSE');
legend('CTR','TR','CNN','SDF','ACMTF','location','best','box','off');
title('User-Loc matrix');

figure;
hold on
p=plot(TRr1,[runtime_c{1}',sum(runtime_c{2},2),runtime_c{3}',runtime_c{5}',runtime_c{4}']);
p(1).Marker='p';
p(2).Marker='o';
p(3).Marker='s';
p(4).Marker='^';
p(5).Marker='+';
xlabel('Tensor rank');
ylabel('CPU time(s)');
legend('CTR','TR_T+TR_M','CNN','SDF','ACMTF','location','best','box','off');