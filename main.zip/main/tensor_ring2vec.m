function [z,Len]=tensor_ring2vec(model,cpd,ucpd,flag_gradient)
L=max(cell2mat(model.dim));
D=cellfun(@length,model.siz);
N=length(model.val);
num0=0;
num1=0;
if ~flag_gradient
    for n=1:N
        if ~isempty(ucpd{n})
            siz=model.siz{n}.*[model.TRr{n}(1:end-1).*model.TRr{n}(2:end),model.TRr{n}(1)*model.TRr{n}(end)];
            [~,ds]=ismember(ucpd{n},model.dim{n});
            for d=ds
                num1=num1+siz(d);
                x(num0+1:num1)=model.fct{n}{d}(:);
                num0=num1;
            end
        end
    end
    num0=0;
    num1=0;
    for l=1:L
        if ~isempty(cpd{l})
            n=cpd{l}(1);
            d=find(model.dim{n}==l);
            siz=model.siz{n}(d)*model.TRr{n}(d)*model.TRr{n}(d*(d~=D(n))+1*(d==D(n)));
            num1=num1+siz;
            y(num0+1:num1)=model.fct{n}{d}(:);
            num0=num1;
        end
    end
    Len=length(x);
    z=[x,y]';
else
    for n=1:length(model.siz)
        if ~isempty(ucpd{n})
            siz=model.siz{n}.*[model.TRr{n}(1:end-1).*model.TRr{n}(2:end),model.TRr{n}(1)*model.TRr{n}(end)];
            [~,ds]=ismember(ucpd{n},model.dim{n});
            for d=ds
                num1=num1+siz(d);
                x(num0+1:num1)=model.grd{n}{d}(:);
                num0=num1;
            end
        end
    end
    num0=0;
    num1=0;
    for l=1:L
        if ~isempty(cpd{l})
            n=cpd{l}(1);
            d=find(model.dim{n}==l);
            siz=model.siz{n}(d)*model.TRr{n}(d)*model.TRr{n}(d*(d~=D(n))+1*(d==D(n)));
            num1=num1+siz;
            y(num0+1:num1)=model.grd{n}{d}(:);
            num0=num1;
        end
    end
    Len=length(x);
    z=[x,y]';
end
end