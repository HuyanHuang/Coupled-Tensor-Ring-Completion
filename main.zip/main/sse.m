function err=sse(x,idx,val)
err=0;
if iscell(x) && iscell(idx) && iscell(val)
    for i=1:length(x)
        err=err+norm(x{i}(idx{i})-val{i},'fro')^2/2;
    end
else
    err=norm(x(idx)-val,'fro')^2/2;
end
end