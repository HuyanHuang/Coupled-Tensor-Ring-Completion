function grad=dtensor_ring(model,cpd,ucpd,C,ind)
% This function calculate the gradient based on A, B, W (C,ind)
L=max(cell2mat(model.dim));
N=length(model.val);
for n=1:N
    if ~isempty(ucpd{n})
        [~,ds]=ismember(ucpd{n},model.dim{n});
        for d=ds
            [A,B]=tensor_ring(model.fct{n},d,model.siz{n});
            grad=zeros(size(A));
            for id=1:model.siz{n}(d)
                Bhat=B(:,ind{n}{d}{id});
                grad(id,:)=(A(id,:)*Bhat-C{n}{d}{id})*Bhat'+model.pnt*A(id,:);
            end
            model.grd{n}=ctensor_ring(model.grd{n},d,grad);
        end
    end
end
for l=1:L
    if ~isempty(cpd{l})
        ns=cpd{l};
        ds=zeros(1,N);
        for n=ns
            ds(n)=find(model.dim{n}==l);
        end
        ds(ds==0)=[];
        grad=0;
        for i=1:length(ns)
            [A,B]=tensor_ring(model.fct{ns(i)},ds(i),model.siz{ns(i)});
            grad_temp=zeros(size(A));
            for id=1:model.siz{ns(i)}(ds(i))
                Bhat=B(:,ind{ns(i)}{ds(i)}{id});
                grad_temp(id,:)=(A(id,:)*Bhat-C{ns(i)}{ds(i)}{id})*Bhat'+model.pnt*A(id,:);
            end
            grad=grad+grad_temp;
        end
        for i=1:length(ns)
            model.grd{ns(i)}=ctensor_ring(model.grd{ns(i)},ds(i),grad);
        end
    end
end
grad=tensor_ring2vec(model,cpd,ucpd,true);
end