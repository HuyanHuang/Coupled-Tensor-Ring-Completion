function out=CTR_AALS(model)
% shared parameters
model.shared.MaxIters = 100;
model.shared.MaxFuncEvals = 4e3;
model.shared.RelFuncTol = -1;
model.shared.GNormTol = 0;
model.shared.TraceFuncEvals = true;
model.shared.TraceFunc = true;
model.shared.TraceRelFunc = true;
model.shared.TraceGradNorm = true;

% linesearch parameters
model.ls.LineSearch_ftol = 1e-4; % 1e-4
model.ls.LineSearch_gtol = 1e-2; % 1e-2
model.ls.LineSearch_initialstep = 1; % 1
model.ls.LineSearch_maxfev = 20; % default 20
model.ls.LineSearch_method = 'more-thuente';
model.ls.LineSearch_stpmax = 1e15;
model.ls.LineSearch_stpmin = 1e-15;
model.ls.LineSearch_xtol = 1e-15;

% NGMRES parameters
model.ngmres = ngmres_prec('defaults');
model.ngmres.W = 20; % Maximum window size
model.ngmres.TraceRestarts = false;  % Flag to include the history of the restarts
model.ngmres.Display = 'iter';  % Options: 'iter', 'final' or 'off'
model.ngmres.UsePrecond = true;
model.ngmres.NoPrecondStep = 'ls'; % if above is false. Options: 'ls','fixed'
model.ngmres.NPrecond = 1;
model.ngmres.AlgorithmVariant = 'ngmres'; % Options: 'ngmres', 'anderson'

% NCG parameters (for comparing NCG with NGMRES)
model.ncg = ncg_prec('defaults');
model.ncg.RestartNW = false;
model.ncg.Display = 'off'; % Options: 'iter', 'final' or 'off'
model.ncg.UsePrecond = true;
model.ncg.Update = 'HS_TP'; % HS_LP or HS_TP

% LBFGS parameters (for comparing LBFGS with NGMRES)
model.lbfgs = lbfgs_prec('defaults');
model.lbfgs.M = 5; % Window size
model.lbfgs.Display = 'iter'; % Options: 'iter', 'final' or 'off'
model.lbfgs.LS_precond = 'modBT';
model.lbfgs.PrecondType = 'LP'; % LP or TP

% Nesterov parameters
model.nesterov = nesterov_prec('defaults');
model.nesterov.Display = 'iter';  % Options: 'iter', 'final' or 'off'
model.nesterov.UsePrecond = true;
model.nesterov.NoPrecondStep = 'ls'; %if above is false. Options: 'ls','fixed'
model.nesterov.eta = 1; % value of eta
model.nesterov.delay = 1; % 1: no delay
model.nesterov.step_type = 4; % 1: step 1; 2: gradient ratio; 3: Nesterov sequence; 4: line search on beta
model.nesterov.restart_type = 1; % 0: no restart; 1: function; 2: gradient; 3: speed (x-based)

% load Shared Parameters;
model = test_SetSharedParameters(model);

% initilize temporary parameters
[cpd,ucpd,C,ind,P]=init_temp_para(model);

% initilize tensor ring
model=init_tensor_ring(model);
[x_init,Len]=tensor_ring2vec(model,cpd,ucpd,false);
nX=length(x_init);

% the fg function
fg = @(x)objfun_CTR(x,model,cpd,ucpd,C,ind,Len);

% nonlinear preconditioner using ALS
g_precond = @(x)CTR_preconditioner(x,model,cpd,ucpd,C,ind,P,Len);
model.lbfgs.FUNPrecond = g_precond;
model.ncg.FUNPrecond = g_precond;
model.ngmres.FUNPrecond = g_precond;
model.nesterov.FUNPrecond = g_precond;

% call the Nesterov method
ngmrestime = cputime;
out = nesterov_prec(fg, x_init, model, model.nesterov);
out.time = cputime-ngmrestime;

% display the result
for i = 2:size(out.TraceFuncEvals,2)
    out.TraceFuncEvals(i) = out.TraceFuncEvals(i)+out.TraceFuncEvals(i-1);
end
fprintf(' Iter   Time   FuncEvals       F(X)          ||G(X)||/N        \n');
fprintf('------  -----  --------- ---------------- ----------------\n');
fprintf('%d %g %d %g %g\n', out.Iters,...
    out.time, round(out.FuncEvals), ...
    out.F, norm(out.G)/nX);

% calculate newly recovered tensor
x=out.X;
model=vec2tensor_ring(x,model,cpd,ucpd,Len);
[~,~,x]=cellfun(@tensor_ring,model.fct,num2cell(ones(1,length(model.gdt))),model.siz,'UniformOutput',false);

% display final result
RMSE=cellfun(@rmse,x,model.gdt);
fprintf('RMSE=');
for n=1:length(model.gdt)
    fprintf('%g\t',RMSE(n));
end
fprintf('\n');
end