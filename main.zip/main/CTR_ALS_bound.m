function [RE,flag]=CTR_ALS_bound(tnsr1,tnsr2,P1,P2,TRr1,TRr2,dim_coupled,tau)
%% initialize parameters
maxiter=200;
epsilon_x=1e-8;
epsilon_y=1e-8;
D1=ndims(tnsr1);
D2=ndims(tnsr2);
J1=size(tnsr1);
J2=size(tnsr2);
RC=nan(maxiter,2);
RE=nan(maxiter,2);
F1=norm(tnsr1(:),2);
F2=norm(tnsr2(:),2);
flag=false;
%% tensor ring approximation
TRr1=TRr1*ones(1,D1);
TRr2=TRr2*ones(1,D2);
x0=initialization_M(J1,find(P1),tnsr1(P1==1));
y0=initialization_M(J2,find(P2),tnsr2(P2==1));
g1=TRg_svd(P1.*tnsr1,J1,TRr1);
g2=TRg_svd(P2.*tnsr2,J2,TRr2);
%% tensor ring completion
t=cputime;
% main loop
for i=1:maxiter
    % original-BCD(block coordinate descent)
    % update the decoupled TR-factors of the first tensor ring
    for n=setdiff(1:D1,dim_coupled)
        % solve each sub-problem
        [A1,B1]=tensor_ring(g1,n,J1);
        C_temp=permute(P1.*tnsr1,[n n+1:D1 1:n-1]);
        C1=reshape(C_temp,J1(n),[]);
        W_temp=permute(P1,[n n+1:D1 1:n-1]);
        W1=reshape(W_temp,J1(n),[]);
        % slove each sub-sub-subproblem (update row by row)
        for j=1:size(A1,1)
            Bhat1=B1(:,W1(j,:)==1);
            Hess_row1=Bhat1*Bhat1';
            A1(j,:)=C1(j,:)*B1'/Hess_row1;
        end
        g1=ctensor_ring(g1,n,A1);
    end
    % update the decoupled TR-factors of the second tensor ring
    for n=setdiff(1:D2,dim_coupled)
        % solve each sub-problem
        [A2,B2]=tensor_ring(g2,n,J2);
        C_temp=permute(P2.*tnsr2,[n n+1:D2 1:n-1]);
        C2=reshape(C_temp,J2(n),[]);
        W_temp=permute(P2,[n n+1:D2 1:n-1]);
        W2=reshape(W_temp,J2(n),[]);
        % slove each sub-sub-subproblem (update row by row)
        for j=1:size(A2,1)
            Bhat2=B2(:,W2(j,:)==1);
            Hess_row2=Bhat2*Bhat2';
            A2(j,:)=C2(j,:)*B2'/Hess_row2;
        end
        g2=ctensor_ring(g2,n,A2);
    end
    % update the coupled TR-factors
    for n=dim_coupled
        % solve each sub-problem
        [A1,B1]=tensor_ring(g1,n,J1);
        C_temp=permute(P1.*tnsr1,[n n+1:D1 1:n-1]);
        C1=reshape(C_temp,J1(n),[]);
        W_temp=permute(P1,[n n+1:D1 1:n-1]);
        W1=reshape(W_temp,J1(n),[]);
        [A2,B2]=tensor_ring(g2,n,J2);
        C_temp=permute(P2.*tnsr2,[n n+1:D2 1:n-1]);
        C2=reshape(C_temp,J1(n),[]);
        W_temp=permute(P2,[n n+1:D2 1:n-1]);
        W2=reshape(W_temp,J2(n),[]);
        Per1_1=reshape(1:TRr1(n)*TRr1(n*(n~=D1)+1*(n==D1)),[],TRr1(n));
        Per1_1=reshape(Per1_1(1:tau(n,2),1:tau(n,1)),1,[]);
        Per1_2=setdiff(1:TRr1(n)*TRr1(n*(n~=D1)+1*(n==D1)),Per1_1);
        Per1=[Per1_1,Per1_2];
        Per2_1=reshape(1:TRr2(n)*TRr2(n*(n~=D2)+1*(n==D2)),[],TRr2(n));
        Per2_1=reshape(Per2_1(1:tau(n,2),1:tau(n,1)),1,[]);
        Per2_2=setdiff(1:TRr2(n)*TRr2(n*(n~=D2)+1*(n==D2)),Per2_1);
        Per2=[Per2_1,Per2_2];
        % slove each sub-sub-subproblem (update row by row)
        for j=1:size(A1,1)
            Bhat1=B1(:,W1(j,:)==1);
            Hess_row1=Bhat1*Bhat1';
            Hess_row1=Hess_row1(Per1,Per1);
            Bhat2=B2(:,W2(j,:)==1);
            Hess_row2=Bhat2*Bhat2';
            Hess_row2=Hess_row2(Per2,Per2);
            Hess_row1_11=Hess_row1(1:prod(tau(n,:)),1:prod(tau(n,:)));
            Hess_row1_12=Hess_row1(1:prod(tau(n,:)),prod(tau(n,:))+1:end);
            Hess_row1_21=Hess_row1(prod(tau(n,:))+1:end,1:prod(tau(n,:)));
            Hess_row1_22=Hess_row1(prod(tau(n,:))+1:end,prod(tau(n,:))+1:end);
            Hess_row2_11=Hess_row2(1:prod(tau(n,:)),1:prod(tau(n,:)));
            Hess_row2_12=Hess_row2(1:prod(tau(n,:)),prod(tau(n,:))+1:end);
            Hess_row2_21=Hess_row2(prod(tau(n,:))+1:end,1:prod(tau(n,:)));
            Hess_row2_22=Hess_row2(prod(tau(n,:))+1:end,prod(tau(n,:))+1:end);
            Hess_row3=[Hess_row1_11+Hess_row2_11  Hess_row1_12+Hess_row1_21'                       Hess_row2_12+Hess_row2_21';...
                       Hess_row1_21+Hess_row1_12' Hess_row1_22                                     zeros(size(Hess_row1_22,1),size(Hess_row2_22,2));...
                       Hess_row2_21+Hess_row2_12' zeros(size(Hess_row2_22,2),size(Hess_row1_22,1)) Hess_row2_22 ];
            xi1=C1(j,:)*B1(Per1,:)';
            eta1=xi1(prod(tau(n,:))+1:end);
            xi1=xi1(1:prod(tau(n,:)));
            xi2=C2(j,:)*B2(Per2,:)';
            eta2=xi2(prod(tau(n,:))+1:end);
            xi2=xi2(1:prod(tau(n,:)));
            c=[xi1+xi2 eta1 eta2];
            vec=c/Hess_row3;
            % update alpha
            A1(j,Per1_1)=vec(1:prod(tau(n,:)));
            A2(j,Per2_1)=vec(1:prod(tau(n,:)));
            % update beta
            A1(j,Per1_2)=vec(prod(tau(n,:))+1:1:TRr1(n)*TRr1(n*(n~=D1)+1*(n==D1)));
            % update gamma
            A2(j,Per2_2)=vec(TRr1(n)*TRr1(n*(n~=D1)+1*(n==D1))+1:end);
        end
        g1=ctensor_ring(g1,n,A1);
        g2=ctensor_ring(g2,n,A2);
    end
    % calculate newly recovered tensor
    [~,~,x]=tensor_ring(g1,1,J1);
    [~,~,y]=tensor_ring(g2,1,J2);
    % compute relative error with respect to cost function
    RC(i,:)=[norm(x(:)-x0(:),2)/norm(x0(:),2),norm(y(:)-y0(:),2)/norm(y0(:),2)];
    RE(i,:)=[norm(x(:)-tnsr1(:),2)/F1,norm(y(:)-tnsr2(:),2)/F2];
%     if mod(i,10)==0
%         fprintf('Iteration=%d\tRC=%f, %f\tRE=%f, %f\n',i,RC(i,1),RC(i,2),RE(i,1),RE(i,2));
%     end
    if RC(i,1)<epsilon_x && RC(i,2)<epsilon_y
        flag=true;
        break
    end
    if RE(i,1)>100 || RE(i,2)>100
        flag=false;
        break
    end
    x0=x;
    y0=y;
end
run_time=cputime-t;
fprintf('running time=%fs\n',run_time);
end