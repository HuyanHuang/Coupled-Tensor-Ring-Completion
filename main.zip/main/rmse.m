function err=rmse(x,y)
err=norm(x(:)-y(:),'fro')/sqrt(numel(x));
end