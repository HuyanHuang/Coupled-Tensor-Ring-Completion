function model=adjust_variable(model,cpd,ucpd,P)
dim=model.dim;
siz=model.siz;
D=cellfun(@length,siz);
N=length(model.val);
L=max(cell2mat(dim));
norm2=cell(1,N);
t=cell(1,N);
for n=1:2
    if ~isempty(ucpd{n})
        norm2{n}=zeros(D(n),1);
        [~,ds]=ismember(ucpd{n},dim{n});
        for d=ds
            norm2{n}(d)=norm(model.fct{n}{d}(:),'fro')^2;
        end
    end
end
for l=1:L
    if ~isempty(cpd{l})
        ds=zeros(1,N);
        ns=cpd{l}(cpd{l}<=2);
        for n=ns
            ds(n)=find(dim{n}==l);
        end
        ds(ds==0)=[];
        norm2_temp=0;
        norm2_temp=norm2_temp+norm(model.fct{ns(1)}{ds(1)}(P{l,ns(1)}{1}),'fro')^2;
        for j=1:length(ds)
            norm2_temp=norm2_temp+norm(model.fct{ns(j)}{ds(j)}(P{l,ns(j)}{2}),'fro')^2;
        end
        for j=1:length(ds)
            norm2{ns(j)}(ds(j))=norm2_temp;
        end
    end
end
% compute temporary parameters delta and ka
delta=cellfun(@prod,norm2);
% delta=zeros(1,N);
% for n=1:2
%     for d=1:D(n)
%         delta(n)=delta(n)+log10(norm2{n}(d));
%     end
% end
L=D(1)-length(ucpd{1});
k1=(delta(2)/delta(1))^(D(2)-L);
k2=(delta(1)/delta(2))^(D(1)-L);
% solve the dual variables mu by root finding
mu=delta.^(1./D(1:2));
% mu(1)=fzero(@(x) (k1*x^((D(1)-D(2))/(D(2)-L))+1)^L*x^D(1)-delta(1),[0,mu(1)]);
% mu(2)=fzero(@(x) (k2*x^((D(2)-D(1))/(D(1)-L))+1)^L*x^D(2)-delta(2),[0,mu(2)]);
mu=fsolve(@(x)myfun(x,D,L,delta),mu,optimoptions('fsolve','Display','off'));
% compute the adjustment coefficients t according to mu and delta
for n=1:2
    if ~isempty(ucpd{n})
        t{n}=zeros(D(n),1);
        [~,ds]=ismember(ucpd{n},dim{n});
        for d=ds
            t{n}(d)=mu(n)/norm2{n}(d);
            model.fct{n}{d}=model.fct{n}{d}*t{n}(d);
        end
    end
end
for l=1:L
    if ~isempty(cpd{l})
        ds=zeros(1,N);
        ns=cpd{l}(cpd{l}<=2);
        for n=ns
            ds(n)=find(dim{n}==l);
        end
        ds(ds==0)=[];
        for j=1:length(ds)
            t{ns(j)}(ds(j))=sum(mu)/norm2{ns(j)}(ds(j));
            model.fct{ns(j)}{ds(j)}=model.fct{ns(j)}{ds(j)}*t{ns(j)}(ds(j));
        end
    end
end
% check if prod(t)==1
% prodt=cellfun(@prod,t);
% if(all(prodt==1))
%    fprintf('yes\n'); 
% end
end

function F=myfun(x,D,L,delta)
F=[sum(x)^L*x(1)^(D(1)-L)-delta(1),sum(x)^L*x(2)^(D(2)-L)-delta(2)];
end