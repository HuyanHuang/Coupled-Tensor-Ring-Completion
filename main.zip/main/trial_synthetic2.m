clc
clear
close all
%% input arguments
d=4;
TRr=2:8;
SR=0.005:0.005:0.1;
I=[20 20 20 20];
model.siz=I;
%% solve
recovery_synthetic=zeros(length(TRr),length(SR),5);
warning off
for m=1:length(TRr)
    % generate tensor ring
    tnsr=TR_rand(I,TRr(m)*ones(1,d));
    for n=1:length(SR)
        for k=1:5
            % generate P
            [model.val,model.idx]=unisam(tnsr,SR(n));
            model.TRr=TRr(m)*ones(1,d);
            model.gdt=tnsr;
            [RE,flag]=TR_FastALS_bound(model);
            if flag
                idx=find(~isnan(RE(:,1)),1,'last');
                recovery_synthetic(m,n,k)=RE(idx,1);
            else
                recovery_synthetic(m,n,k)=nan;
            end
        end
    end
end
warning on
save recovery_synthetic recovery_synthetic
%% visualize the results
err_c=squeeze(mean(recovery_synthetic,3,'omitnan'));
err_c(isnan(err_c))=inf;
err_c=(err_c*norm(tnsr(:),2))/20^2;
figure;
imagesc([TRr(1) TRr(end)],[SR(1) SR(end)],log10(squeeze(err_c)'));
xlabel('TR rank');
ylabel('SR');
colormap(flipud(gray));
caxis([-6 0]);
set(gca,'YDir','normal');
% colorbar('Ticks',[-6 0],'TickLabels',{'<10^{-6}','10^{0}'},'Direction','reverse');