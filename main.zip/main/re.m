function err=re(x,y)
err=norm(x(:),2)/norm(y(:),'fro');
end