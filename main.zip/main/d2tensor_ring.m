function Hess=d2tensor_ring(A,B,W)
% This function calculate the Hessian matrix based on A, B, W
I=size(A,1);
K=size(B,1);
Hess=zeros(K,K,I);
for i=1:I
    Hess(:,:,i)=(repmat(W(i,:),K,1).*B)*B';
end
end