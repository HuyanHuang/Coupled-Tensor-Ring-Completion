function [g,nfev]=CTR_preconditioner(x,model,cpd,ucpd,C,ind,P,Len)
% initialize parameters
model=vec2tensor_ring(x,model,cpd,ucpd,Len);
dim=model.dim;
siz=model.siz;
tau=model.tau;
lambda=model.pnt;
L=max(cell2mat(dim));
N=length(model.val);
% original-BCD(block coordinate descent)
% update the uncoupled TR-factors
for n=1:N
    if ~isempty(ucpd{n})
        [~,ds]=ismember(ucpd{n},dim{n});
        % solve each sub-problem
        for d=ds
            [A,B]=tensor_ring(model.fct{n},d,siz{n});
            % slove each sub-sub-subproblem (update row by row)
            for id=1:siz{n}(d)
                Bhat=B(:,ind{n}{d}{id});
                Hess=Bhat*Bhat';
                A(id,:)=C{n}{d}{id}*Bhat'/(Hess+lambda*eye(size(Hess)));
%                 A(id,:)=lsqminnorm(Hess+lambda*eye(size(Hess)),Bhat*C{n}{d}{id}');
            end
            model.fct{n}=ctensor_ring(model.fct{n},d,A);
        end
    end
end
% update the coupled TR-factors
for l=1:L
    if ~isempty(cpd{l})
        % solve each sub-problem
        ds=zeros(1,N);
        for n=cpd{l}
            ds(n)=find(dim{n}==l);
        end
        ds(ds==0)=[];
        A=cell(1,length(ds));
        B=cell(1,length(ds));
        for j=1:length(ds)
            [A{j},B{j}]=tensor_ring(model.fct{cpd{l}(j)},ds(j),siz{cpd{l}(j)});
        end
        % slove each sub-sub-subproblem (update row by row)
        for id=1:siz{n}(ds(end))
            Hess=cell(length(ds)+1);
            Hess{1,1}=0;
            f=cell(1,length(ds)+1);
            f{1}=0;
            j=1;
            for n=cpd{l}
                Bhat=B{j}(:,ind{n}{ds(j)}{id});
                Per=[P{l,n}{1},P{l,n}{2}];
                Bhat=Bhat(Per,:);
                Hessn=Bhat*Bhat';
                K=prod(tau{n}(ds(j),:));
                Hess{1,1}=Hess{1,1}+Hessn(1:K,1:K);
                Hess{1,j+1}=Hessn(1:K,K+1:end)+Hessn(K+1:end,1:K)';
                Hess{j+1,1}=Hess{1,j+1}';
                Hess{j+1,j+1}=Hessn(K+1:end,K+1:end);
                xi=C{n}{ds(j)}{id}*Bhat';
                eta=xi(K+1:end);
                xi=xi(1:K);
                f{1}=f{1}+xi;
                f{j+1}=eta;
                j=j+1;
            end
            % eliminate the empty cells
            Ind=find(~cellfun(@isempty,Hess(1:length(ds)+1)),1,'last');
            Hess=Hess(1:Ind,1:Ind);
            Idx=find(cellfun(@isempty,Hess));
            [a,b]=ind2sub((length(ds)+1)*[1,1],Idx);
            for h=1:length(Idx)
                Hess{Idx(h)}=zeros(size(Hess{a(h),1},1),size(Hess{1,b(h)},2));
            end
            Hess=cell2mat(Hess);
            vlen=cellfun(@length,f);
            f=cell2mat(f);
            vec=f/(Hess+lambda*eye(size(Hess)));
%             vec=lsqminnorm(Hess+lambda*eye(size(Hess)),f')';
            vec=mat2cell(vec,1,vlen);
            j=1;
            for n=cpd{l}
                % update alpha
                A{j}(id,P{l,n}{1})=vec{1};
                % update beta, gamma, etc.
                A{j}(id,P{l,n}{2})=vec{j+1};
                j=j+1;
            end
        end
        for j=1:length(ds)
            model.fct{cpd{l}(j)}=ctensor_ring(model.fct{cpd{l}(j)},ds(j),A{j});
        end
    end
end
x1=tensor_ring2vec(model,cpd,ucpd,false);
g=x-x1;
nfev=1;
end