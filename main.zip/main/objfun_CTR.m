function [F,grad]=objfun_CTR(x,model,cpd,ucpd,C,ind,Len)
% objective function
N=length(model.val);
model=vec2tensor_ring(x,model,cpd,ucpd,Len);
[~,~,tnsr]=cellfun(@tensor_ring,model.fct,num2cell(ones(1,length(model.gdt))),model.siz,'UniformOutput',false);
F=0;
for n=1:N
    F=F+norm(tnsr{n}(model.idx{n})-model.val{n},'fro')^2/2;
end
F=F+model.pnt*norm(x,'fro')^2/2;
% F=[];
% for n=1:N
%     F=[F;tnsr{n}(model.idx{n})-model.val{n}];
% end
if nargout>1
    grad=dtensor_ring(model,cpd,ucpd,C,ind);
end
end