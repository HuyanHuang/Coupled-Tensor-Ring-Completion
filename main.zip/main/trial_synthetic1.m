clc
clear
close all
%% input arguments
d1=4;
d2=4;
TRr1=2:8;
TRr2=2:8;
SR1=0.005:0.005:0.1;
SR2=0.05:0.05:0.2;
I1=[20 20 20 20];
I2=[20 20 20 20];
dim_coupled={1,1:2,1:3};
%% solve
recovery1_synthetic=cell(1,4);
recovery2_synthetic=cell(1,4);
err1_c=cell(1,4);
err2_c=cell(1,4);
warning off
for i=1:length(dim_coupled)
    for j=1:length(SR2)
        for m=1:length(TRr1)
            % generate tensor ring
            g1=TRcore_init(I1,TRr1(m)*ones(1,d1),'gaussian');
            g2=TRcore_init(I2,TRr2(m)*ones(1,d2),'gaussian');
            for t=dim_coupled{i}
                g1{t}(1:min(TRr1(m),TRr2(m)),:,1:min(TRr1(m),TRr2(m)))=g2{t}(1:min(TRr1(m),TRr2(m)),:,1:min(TRr1(m),TRr2(m)));
            end
            [~,~,tnsr1]=tensor_ring(g1,1,I1);
            [~,~,tnsr2]=tensor_ring(g2,1,I2);
            % initialize tau
            tau=zeros(min(d1,d2),2);
            for t=dim_coupled{i}
                tau(t,:)=[min(TRr1(m),TRr2(m)) min(TRr1(m),TRr2(m))];
            end
            % generate P2
            P2=sampling_uniform(tnsr2,SR2(j));
            for n=1:length(SR1)
                for k=1:5
                    % generate P1
                    P1=sampling_uniform(tnsr1,SR1(n));
                    [RE,flag]=CTR_ALS_bound(tnsr1,tnsr2,P1,P2,TRr1(m),TRr2(m),dim_coupled{i},tau);
                    if flag
                        idx1=find(~isnan(RE(:,1)),1,'last');
                        recovery1_synthetic{i}(j,m,n,k)=RE(idx1,1);
                        idx2=find(~isnan(RE(:,2)),1,'last');
                        recovery2_synthetic{i}(j,m,n,k)=RE(idx2,1);
                    else
                        recovery1_synthetic{i}(j,m,n,k)=nan;
                        recovery2_synthetic{i}(j,m,n,k)=nan;
                    end
                end
            end
        end
    end
end
warning on
save recovery1_synthetic recovery1_synthetic
save recovery2_synthetic recovery2_synthetic
%% visualize the results
for i=1:length(err1_c)
    err1_c{i}=squeeze(mean(recovery1_synthetic{i},4,'omitnan'));
    err1_c{i}(isnan(err1_c{i}))=inf;
    err1_c{i}=(err1_c{i}*norm(tnsr1(:),2))/20^2;
    err2_c{i}=squeeze(mean(recovery2_synthetic{i},4,'omitnan'));
    err2_c{i}(isnan(err2_c{i}))=inf;
    err2_c{i}=(err2_c{i}*norm(tnsr2(:),2))/20^2;
end
figure;
for i=1:length(recovery1_synthetic)
    for j=1:length(SR2)
        subplot(3,4,j+4*(i-1))
        imagesc([TRr1(1) TRr1(end)],[SR1(1) SR1(end)],log10(squeeze(err1_c{i}(j,:,:))'));
        if i==3
            xlabel('TR rank');
        end
        if j==1
            ylabel('SR_1');
        end
        colormap(flipud(gray));
        caxis([-6 0]);
        set(gca,'YDir','normal');
        title(['Dim_c=' num2str(length(dim_coupled{i})) ', SR_2=' num2str(SR2(j))]);
    end
%     colorbar('Ticks',[-6 0],'TickLabels',{'<10^{-6}','10^{0}'},'Direction','reverse');
end