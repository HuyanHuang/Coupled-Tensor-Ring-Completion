clc
clear
close all
%% generate data
num_trial=10;
sigma = 10;
beta = 8/3;
rho = 28;
f = @(t,a) [-sigma*a(1) + sigma*a(2); rho*a(1) - a(2) - a(1)*a(3); -beta*a(3) + a(1)*a(2)];
xt0 = [10,20,10];
[tspan,a] = ode45(f,[0 100],xt0);
C=corrcoef(a(100+(1:4096),:));
%% trial
RMSE_CTR=zeros(num_trial,5,2);
RMSE_TR=zeros(num_trial,5,2);

time_CTR=zeros(num_trial,5);
time_TR=zeros(num_trial,5,2);
for h=1:num_trial
    % CTR
    SR={0.5,0.5};
    model.siz={4*ones(1,6),4*ones(1,6)};
    model.TRr={8*ones(1,6),8*ones(1,6)};
    for i=1:2
        model.gdt{i}=reshape(a(100+(1:4096),i),model.siz{i});
        [model.val{i},model.idx{i}]=unisam(model.gdt{i},SR{i});
    end
    for l=1:5
        model.dim={[1:l,l+1:6],[1:l,7:12-l]};
        for i=1:2
            model.tau{i}=zeros(6,2);
            model.tau{i}(1:l,:)=8;
        end
        [x,RC,RMSE,time_CTR(h,l)]=CTR_ALS(model,false);
        RMSE_CTR(h,l,:)=min(RMSE);
    end
    % TR
    for i=1:2
        model1.siz=4*ones(1,6);
        model1.TRr=8*ones(1,6);
        model1.gdt=model.gdt{i};
        model1.val=model.val{i};
        model1.idx=model.idx{i};
        [x,RC,RMSE,time_TR(h,:,i)]=TR_FastALS(model1,false);
        if i==1
            RMSE_TR(h,:,1)=min(RMSE);
        else
            RMSE_TR(h,:,2)=min(RMSE);
        end
    end
end
%% save
recovery_Lorenz.method{1}='CTR';
recovery_Lorenz.RMSE{1}=RMSE_CTR;
recovery_Lorenz.runtime{1}=time_CTR;

recovery_Lorenz.method{2}='TR';
recovery_Lorenz.RMSE{2}=RMSE_TR;
recovery_Lorenz.runtime{2}=time_TR;
save recovery_Lorenz recovery_Lorenz
%% manipulation
RMSE_c=cellfun(@mean,recovery_Lorenz.RMSE,'UniformOutput',false);
RMSE_c=cellfun(@squeeze,RMSE_c,'UniformOutput',false);
runtime_c=cellfun(@mean,recovery_Lorenz.runtime,'UniformOutput',false);
runtime_c=cellfun(@squeeze,runtime_c,'UniformOutput',false);
%% visualization
figure;
subplot(2,1,1);
hold on
p=plot(1:5,[RMSE_c{1}(:,1),RMSE_c{2}(:,1)]);
p(1).Marker='p';
p(2).Marker='o';
xlabel('# coupled dimensions');
ylabel('RMSE');
legend('CTR','TR','location','best');
title('X coordinate');
subplot(2,1,2);
hold on
p=plot(1:5,[RMSE_c{1}(:,2),RMSE_c{2}(:,2)]);
p(1).Marker='p';
p(2).Marker='o';
xlabel('# coupled dimensions');
ylabel('RMSE');
legend('CTR','TR','location','best');
title('Y coordinate');

figure;
hold on
p=plot(1:5,[runtime_c{1}',sum(runtime_c{2},2)]);
p(1).Marker='p';
p(2).Marker='o';
xlabel('# coupled dimensions');
ylabel('CPU time(s)');
legend('CTR','TR_X+TR_Y','Location','Best');