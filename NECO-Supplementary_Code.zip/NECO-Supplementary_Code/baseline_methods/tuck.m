function T =  tuck(A,B,C,R,R1,R2,R3)

% tuck creates a tensor using components from Tucker decomposition. 
% A,B,C - Component matrices
% R - Core tensor
% R1, R2, R3 - Multilinear ranks of tensors

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.



T = zeros(size(A,1),size(B,1),size(C,1));

for l = 1:size(A,1)
    for m = 1:size(B,1)
        for n = 1:size(C,1)
            for i = 1:R1
                for j = 1:R2
                    for k = 1:R3
                            T(l,m,n) = T(l,m,n) + R(i,j,k)*A(l,i)*B(m,j)*C(n,k); 
                    end
                end
            end
       end
   end
end

end