% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

% This program uses the MATLAB CMTF Toolbox
% http://www.models.life.ku.dk/joda/CMTF_Toolbox 
% E. Acar, E. E. Papalexakis, G. Gurdeniz,  M. A. Rasmussen,  A. J. Lawaetz, M. Nilsson,  R. Bro, 
% Structure-Revealing Data Fusion, BMC Bioinformatics, 15: 239, 2014.

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

clear all;

a = load('c1_aaa1.mat');

b1 = [0, 10^(-5),  10^(-4), 10^(-3), 10^(-2), 10^(-1), 1]  
b2 = [0, 10^(-5),  10^(-4), 10^(-3), 10^(-2), 10^(-1), 1]  

res_T = zeros(3,10,5);
res_M = zeros(3,10,5);
res = zeros(3,10,5);

R = 5; % rank


for ii = 1:5
for i = 1:10
    for j = 1:3
        cv = zeros(size(b1,2),size(b2,2));
        
        for k = 1:size(b1,2)
            for l = 1:size(b2,2)
params = inputParser;
params.addParamValue('R', R, @(x) x > 0);
params.addParamValue('size', [a.sz(1,1) a.sz(1,2) a.sz(1,3) a.szm(1,2)], @isnumeric);
params.addParamValue('beta_cp', b1(k), @(x) x >= 0);
params.addParamValue('beta_pca', b2(l), @(x) x >= 0);
params.addParamValue('modes', {[1 2 3], [1 4]}, @iscell);
params.addParamValue('lambdas', {[1 1 1], [1 1 1]}, @iscell);
params.addParamValue('M',[0.5 0.5], @isnumeric);
params.addParamValue('flag_sparse',[0 0], @isnumeric);
params.addParamValue('init', 'random', @(x) (isstruct(x) || ismember(x,{'random','nvecs'})));
params.parse();

lambdas     = params.Results.lambdas;
modes       = params.Results.modes;
sz          = params.Results.size;
R           = params.Results.R
init        = params.Results.init;
beta_cp     = params.Results.beta_cp;
beta_pca    = params.Results.beta_pca;
M           = params.Results.M;
flag_sparse = params.Results.flag_sparse;

% preparation of data for training
X{1} = a.X.T{i};
X{2} = a.X.M{i};

W1 = zeros(a.sz);
W1(a.X.train{i}{j}) = 1;
W{1} = tensor(W1); 

W2 = zeros(a.szm);
W2(a.X.trainM{i}{j}) = 1;
W{2} = tensor(W2); 

Z.object{1} = W{1}.*X{1};
Z.object{2} = W{2}.*X{2};

Z.miss{1}   = W{1};
Z.miss{2}   = W{2};
Z.modes = modes;
Z.size  = sz;


options = ncg('defaults');
options.Display ='final';
options.MaxFuncEvals = 10000;
options.MaxIters     = 1000;
options.StopTol      = 1e-4;
options.RelFuncTol   = 1e-4;

% fit ACMTF-OPT
[Zhat,Init,out] = acmtf_opt(Z,R,'init',init,'alg_options',options, 'beta_cp', beta_cp, 'beta_pca', beta_pca);        
data.Zhat  = Zhat;
data.W     = W;
data.Xorig = X;
data.Init  = Init;
data.out   = out;


size(Zhat{1}.U{1}) , size(Zhat{1}.U{2}) ,size(Zhat{1}.U{3}) ,Zhat{1}.lambda
T_ = create_CP_tensor(Zhat{1}.U{1} , Zhat{1}.U{2} ,Zhat{1}.U{3},  Zhat{1}.lambda);
cv(k,l) = norm(X{1}(a.X.val{i}{j}) - T_(a.X.val{i}{j})); 

cv1{i}{j} = cv;

end
end
        
% Cross validation
 [min_b1, min_b2] = find(cv == min(min(cv)))
    
    
params = inputParser;
params.addParamValue('R', R, @(x) x > 0);
params.addParamValue('size', [a.sz(1,1) a.sz(1,2) a.sz(1,3) a.szm(1,2)], @isnumeric);
params.addParamValue('beta_cp', b1(min_b1), @(x) x >= 0);
params.addParamValue('beta_pca', b2(min_b2), @(x) x >= 0);
params.addParamValue('modes', {[1 2 3], [1 4]}, @iscell);
params.addParamValue('lambdas', {[1 1 1], [1 1 1]}, @iscell);
params.addParamValue('M',[0.5 0.5], @isnumeric);
params.addParamValue('flag_sparse',[0 0], @isnumeric);
params.addParamValue('init', 'random', @(x) (isstruct(x) || ismember(x,{'random','nvecs'})));
params.parse();

lambdas     = params.Results.lambdas;
modes       = params.Results.modes;
sz          = params.Results.size;
R           = params.Results.R
init        = params.Results.init;
beta_cp     = params.Results.beta_cp;
beta_pca    = params.Results.beta_pca;
M           = params.Results.M;
flag_sparse = params.Results.flag_sparse;

% preparation of data for training
X{1} = a.X.T{i};
X{2} = a.X.M{i};

W1 = zeros(a.sz);
W1(a.X.train{i}{j}) = 1;
W{1} = tensor(W1); 

W2 = zeros(a.szm);
W2(a.X.trainM{i}{j}) = 1;
W{2} = tensor(W2); 

Z.object{1} = W{1}.*X{1};
Z.object{2} = W{2}.*X{2};

Z.miss{1}   = W{1};
Z.miss{2}   = W{2};
Z.modes = modes;
Z.size  = sz;


options = ncg('defaults');
options.Display ='final';
options.MaxFuncEvals = 10000;
options.MaxIters     = 1000;
options.StopTol      = 1e-4;
options.RelFuncTol   = 1e-4;

% fit ACMTF-OPT
[Zhat,Init,out] = acmtf_opt(Z,R,'init',init,'alg_options',options, 'beta_cp', beta_cp, 'beta_pca', beta_pca); 
        
T_ = create_CP_tensor(Zhat{1}.U{1} , Zhat{1}.U{2} ,Zhat{1}.U{3},  Zhat{1}.lambda);
M_ = create_matrix(Zhat{2}.U{1} , Zhat{2}.U{2} ,  Zhat{2}.lambda);
res_T(i,j,ii) = norm(X{1}(a.X.test{i}{j}) - T_(a.X.test{i}{j})); 

% Save results
sname = strcat('st_acar_T_UCLAF' , num2str(i), num2str(j), '.mat');
save(sname, 'res_T');
sname = strcat('rcvst_acar_UCLAF' , num2str(i), num2str(j)  , '.mat');
save(sname, 'cv1');
sname = strcat('Z_UCLAF' , num2str(i), num2str(j)  , '.mat');
save(sname, 'Zhat');


end
end
end
            