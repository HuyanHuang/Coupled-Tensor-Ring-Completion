function [A,B,C,D,Tf] = simulate_PLTF_coupled_Tucker(T, M, indT, indM, R1,R2,R3)

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

% Our implementation of the PLTF from B. Ermis, E. Acar, and A. T. Cemgil. Link prediction in heterogeneous data via generalized 
% coupled tensor  factorization. Data Mining and Knowledge Discovery, 29(1), 2015.

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.


sizeT = size(T);
sizeM = size(M);

A = rand(sizeT(1) ,R1);
B = rand(sizeT(2) ,R2);
C = rand(sizeT(3) ,R3);
D = rand(sizeM(2) ,R1);
R = rand(R1,R2,R3);

for iter = 1:750

    M_ =  cpm(A,D,R1);
    T_ =  tuck(A,B,C,R,R1,R2,R3);
    size(T_);
    size(indT);
    TM = (T.*indT)./(T_ + 1.0e-10);
    MM = (M.*indM)./(M_ + 1.0e-10);
    
    tA = zeros(sizeT(1), R1);
    tA1 = zeros(sizeM(1), R1);
     for i = 1:R1
        for l = 1:size(A,1)
            sum = 0;
            for j = 1:R2    
                for k = 1:R3
                    for m = 1:size(B,1)
                        for n = 1:size(C,1)
                            tA(l,i) = tA(l,i) + TM(l,m,n)*B(m,j)*C(n,k)*R(i,j,k); 
                            sum = sum + indT(l,m,n)*B(m,j)*C(n,k)*R(i,j,k);
                        end
                    end
                end
            end
            
            sum1 = 0;
            for o = 1:sizeM(2)
                tA1(l,i) = tA1(l,i) + MM(l,o)*D(o,i);
                sum1 = sum1 + indM(l,o)*D(o,i);
            end
            A(l,i) = A(l,i)*(tA(l,i) + tA1(l,i))/(sum + sum1);
        end
    end
 
 
    T_ =  tuck(A,B,C,R,R1,R2,R3);
    TM = (T.*indT)./(T_ + 1.0e-10);
    tB = zeros(sizeT(2), R2);
    for j = 1:R2
        for m = 1:size(B,1)
            sum = 0;
            for i = 1:R1
                for k = 1:R3
                     for l = 1:size(A,1)
                        for n = 1:size(C,1)
                            tB(m,j) = tB(m,j) + TM(l,m,n)*A(l,i)*C(n,k)*R(i,j,k); 
                            sum = sum + indT(l,m,n)*A(l,i)*C(n,k)*R(i,j,k);
                        end
                    end
                end
            end
            B(m,j) = B(m,j)*tB(m,j)/sum;
        end
    end
    
    T_ =  tuck(A,B,C,R,R1,R2,R3);
    TM = (T.*indT)./(T_ + 1.0e-10);
    tC = zeros(sizeT(3), R3);
     for k = 1:R3 
         for n = 1:size(C,1)
            sum = 0;
            for i = 1:R1
                for j = 1:R2
                     for l = 1:size(A,1)
                        for m = 1:size(B,1)
                            tC(n,k) = tC(n,k) + TM(l,m,n)*A(l,i)*B(m,j)*R(i,j,k); 
                            sum = sum + indT(l,m,n)*A(l,i)*B(m,j)*R(i,j,k);
                        end
                    end
                end
            end
            C(n,k) = C(n,k)*tC(n,k)/sum;
        end
    end
 
    T_ =  tuck(A,B,C,R,R1,R2,R3);
    TM = (T.*indT)./(T_ + 1.0e-10);
    tR = zeros(R1,R2,R3);
    for i = 1:R1
        for j = 1:R2
            for k = 1:R3
                sum = 0;
                for l = 1:size(A,1)
                    for m = 1:size(B,1)
                        for n = 1:size(C,1)
                            tR(i,j,k) = tR(i,j,k) + TM(l,m,n)*A(l,i)*B(m,j)*C(n,k); 
                            sum = sum + indT(l,m,n)*A(l,i)*B(m,j)*C(n,k);
                        end
                    end
                end
                R(i,j,k) = R(i,j,k)*tR(i,j,k)/sum;
            end
        end
    end
    
  
    
    M_ =  cpm(A,D,R);
    MM = (M.*indM)./(M_ + 1.0e-10);
    tD = zeros(sizeM(2) ,R1);
       
     for r = 1:R1
        for i = 1:size(D,1)
             sum = 0;  
             for j = 1:size(A,1)
                    tD(i,r) = tD(i,r) + MM(j,i)*A(j,r);
                    sum = sum + indM(j,i)*A(j,r);
             end
             D(i,r) = D(i,r)*tD(i,r)/(sum );
        end
    end
    
    
end

Tf =  tuck(A,B,C,R,R1,R2,R3);

end


function T =  cp(A,B,C,R)
T = zeros(size(A,1),size(B,1),size(C,1));

for r = 1:R
    tmp = A(:,r)*B(:,r)';
    for i = 1:size(C(:,r),1)
        T(:,:,i) = T(:,:,i) + tmp*C(i,r);
    end
end

end


function T =  tuck(A,B,C,R,R1,R2,R3)
T = zeros(size(A,1),size(B,1),size(C,1));

for l = 1:size(A,1)
    for m = 1:size(B,1)
        for n = 1:size(C,1)
            for i = 1:R1
                for j = 1:R2
                    for k = 1:R3
                            T(l,m,n) = T(l,m,n) + R(i,j,k)*A(l,i)*B(m,j)*C(n,k); 
                    end
                end
            end
       end
   end
end

end


function T =  cpm(A,B,R)


T = A*B';

end




