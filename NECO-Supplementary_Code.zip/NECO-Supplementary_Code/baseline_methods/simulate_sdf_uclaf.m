function simulate_sdf_uclaf()
% This program uses Tensorlab 3.0 (https://www.tensorlab.net) 
% simulate_sdf_uclaf implements structured data fusion using Tucker
% decomposition. This program is specific to learning from the UCLAF
% dataset.


% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com


%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

ssize = 3;

fname = strcat('c1_aaa1.mat');
X = load(fname);

res = zeros(1,20,5);
res_t = zeros(1,20,5);

% Specify the multilinear rank (r1,r2,r3) as R1 = r1, R2 = r2, R3 = r3.
R1 = 3;
R2 = 3;
R3 = 3;

for k = 1:5
for it = 1:10
for j = 1:ssize

    

Ttr = X.X.train{it}{j}';
Tv = X.X.val{it}{j}';
Tt = X.X.test{it}{j}';
Mtr = X.X.trainM{it}{j}';



lambda =  exp(linspace(log(0.01), log(10000), 100)); 
spg = size(lambda , 2);

cv = zeros(spg ,1 );



parfor l = 1:spg

T = X.T;
M = X.M;

T_missing = T;
T_missing([X.X.val{it}{j} X.X.test{it}{j}]) = nan;
T_missing = fmt(T_missing);
M_missing = M;



model = struct;
model.variables.a = randn(size(T,1),R1);
model.variables.b = randn(size(T,2),R2);
model.variables.c = randn(size(T,3),R3);
model.variables.s = randn([R1 R2 R3]);
model.variables.d = randn(size(M,2),R1);
model.factors.A = 'a';
model.factors.B = 'b';
model.factors.C = 'c';
model.factors.S = 's';
model.factors.D = 'd';
model.factorizations.tensor.data = T_missing;
model.factorizations.tensor.lmlra = {'A', 'B', 'C','S'};
%model.factorizations.tensor.weight = 1;
model.factorizations.matrix.data = M_missing;
model.factorizations.matrix.cpd = {'A', 'D'};
%model.factorizations.matrix.weight = 0.5;
model.factorizations.regA.regL2 = {'A', 'B', 'C','S', 'D'};
model.factorizations.regA.weight = lambda(l);
%sdf_check(model, 'print');

options = struct;
options.Display = 200;
options.MaxIter = 1000;
[sol, output] = sdf_nls(model, options);

T1 = tuck(sol.factors.A, sol.factors.B, sol.factors.C, sol.factors.S ,R1,R2,R3);
M1 = sol.factors.A*sol.factors.D';  
    
cv(l,1) = norm(T1(Tv) - T(Tv))  

end

mindx = find(min(cv) == cv);
mindx
cv1{it}{j}{k} = cv;



T = X.T;
M = X.M;

T_missing = T;
T_missing([X.X.val{it}{j} X.X.test{it}{j}]) = nan;
T_missing = fmt(T_missing);
M_missing = M;



model = struct;
model.variables.a = randn(size(T,1),R1);
model.variables.b = randn(size(T,2),R2);
model.variables.c = randn(size(T,3),R3);
model.variables.s = randn([R1 R2 R3]);
model.variables.d = randn(size(M,2),R1);
model.factors.A = 'a';
model.factors.B = 'b';
model.factors.C = 'c';
model.factors.S = 's';
model.factors.D = 'd';
model.factorizations.tensor.data = T_missing;
model.factorizations.tensor.lmlra = {'A', 'B', 'C','S'};
%model.factorizations.tensor.weight = 1;
model.factorizations.matrix.data = M_missing;
model.factorizations.matrix.cpd = {'A', 'D'};
%model.factorizations.matrix.weight = 0.5;
model.factorizations.regA.regL2 = {'A', 'B', 'C','S', 'D'};
model.factorizations.regA.weight = lambda(mindx(1,1));
sdf_check(model, 'print');

options = struct;
options.Display = 200;
options.MaxIter = 1000;
[sol, output] = sdf_nls(model, options);

T1 = tuck(sol.factors.A, sol.factors.B, sol.factors.C, sol.factors.S ,R1,R2,R3);
M1 = sol.factors.A*sol.factors.D';


res(j,it,k) =  norm(T1(Tt) - T(Tt)) ;
res_t(j,it,k) = norm(T1(Tt) - T(Tt));


WM{it} = M1;
WT{it}{1} = T1;




sname = strcat('res_sdf_UCLAF_' , num2str(it), num2str(ssize),   '.mat');
save(sname, 'res');
sname = strcat('res_sdf_UCLAF_t_' , num2str(it), num2str(ssize),  '.mat');
save(sname, 'res_t');
sname = strcat('cv_cp_sc_UCLAF_' , num2str(it), num2str(ssize),  '.mat');
save(sname, 'cv1');
sname = strcat('WM_cp_sc_UCLAF_' , num2str(it), num2str(ssize),  '.mat');
save(sname, 'WM');
sname = strcat('WT_cp_sc_UCLAF_' , num2str(it), num2str(ssize),  '.mat');
save(sname, 'WT');


end
end
end


end
