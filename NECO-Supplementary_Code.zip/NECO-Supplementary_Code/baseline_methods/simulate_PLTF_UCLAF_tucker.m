function simulate_PLTF_UCLAF_tucker()

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

% This program runs PLTF_coupled_Tucker on UCLAF data.

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

ssize = 3;

fname = strcat('c1_aaa1.mat');
X = load(fname);


res_t = zeros(3,20,5);


for it = 1:10
for j = 1:ssize
for k = 1:5

ind_T = X.sz;
ind_M = X.szm;

Ttr = X.X.train{it}{j}';
Tv = X.X.val{it}{j}';
Tt = X.X.test{it}{j}';

Mtr = X.X.trainM{it}{j}';


T = X.X.T{it};
M = X.X.M{it};

TM = zeros(ind_T);
TM(Ttr) = 1;

MM = zeros(ind_M);
MM(Mtr) = 1;


TT = zeros(ind_T);
TT(Ttr) = abs(T(Ttr));
MMM = zeros(ind_M);
MMM(Mtr) = abs(M(Mtr));


[A,B,C,D,Tf] = PLTF_coupled_Tucker(T, M, TM, MM, 5,5,5); % Multilinear rank set to (5,5,5)

res_t(j,it,k) = norm(abs(Tf(Tt)) - abs(T(Tt)));

WT{it}{j}.A = A;
WT{it}{j}.B = B;
WT{it}{j}.C = C;
WT{it}{j}.D = D;
WT{it}{j}.Tf = Tf;


sname = strcat('res_pltf_tuck_n_' , num2str(it), num2str(ssize), '.mat');
save(sname, 'res_t');
sname = strcat('WT_pltf_tuck_n_' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'WT');


end
end
end


end
