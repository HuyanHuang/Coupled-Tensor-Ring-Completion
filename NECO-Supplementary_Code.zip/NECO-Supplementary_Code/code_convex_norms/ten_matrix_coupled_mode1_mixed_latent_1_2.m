function [T1,T2, M1] = ten_matrix_coupled_mode1_mixed_latent_1_2(T, M, indT, indM, beta, lambda1, lambda2, lambda3)

% ten_matrix_coupled_mode1_overlap_dual implements 
% the coupeld completion using the coupled norm \|.,.\|_{(O,O,S)}. 
% T - coupled tensor
% M - coupled matrix 
% indT - indexes of the observed elements of T
% indM - indexes of the observed elements of M
% beta - proximity parameter for ADMM
% lambda1 - regularization parameter with respect to mode 1
% lambda2 - regularization parameter with respect to mode 2
% lambda3 - regularization parameter with respect to mode 3
% T1, T2 - completed latent tensors
% ZM - completed matrix

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com



%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

sizeT = size(T);
[sxM syM] = size(M);

vT = indT;
vX = indM;

T1 = rand(size(T));
T2 = rand(size(T));


M1 = zeros(size(M));

Y1_1 = rand(size(T));
Y1_2 = rand(size(T));
Y1_3 =rand(size(T));

X1 = zeros(size(M));


W1 = rand(size(M));
W3_1 = rand(size(T));
W3_2 = rand(size(T));
W3_3 = rand(size(T));


iter = 0;

ssT = size(T);
sizeTp = prod(ssT);
L = sparse(2*sizeTp,2*sizeTp);
I_ = sparse(sizeTp,1);
I_(vT) = 1;
II = sparse(diag(ones(sizeTp,1)));


L(1:sizeTp,1:sizeTp) = diag(I_) + 2*beta*II;
L(1:sizeTp,(sizeTp+1):2*sizeTp) = diag(I_);
L((sizeTp+1):2*sizeTp , 1:sizeTp ) = diag(I_);
L((sizeTp+1):2*sizeTp ,(sizeTp+1):2*sizeTp) = diag(I_) + beta*II; 

T_ =zeros(ssT);
T_(vT) = T(vT);

while true

[M1] = solve_matrix(M, vX, M1, W1, X1, beta);


R = zeros(2*sizeTp,1);

R(1:sizeTp,1) = reshape(T_ , [sizeTp,1]) - reshape(W3_1,[sizeTp,1]) - reshape(W3_2,[sizeTp,1]) + beta*(reshape(Y1_1,[sizeTp,1]) + reshape(Y1_2,[sizeTp,1]));
R((sizeTp+1):2*sizeTp,1) = reshape(T_ , [sizeTp,1]) - reshape(W3_3,[sizeTp,1]) + beta*reshape(Y1_3,[sizeTp,1]);

r = L\R;

T1 = reshape(r(1:sizeTp), ssT );
T2 = reshape(r((sizeTp+1):2*sizeTp), ssT );  


% Trace norm 
t_TX = [M1 flatten(T1,1)];
t_W3 = [W1 flatten(W3_1,1)];


t_TXp = prox_nuc(t_TX + t_W3/beta, lambda1);
X1 = t_TXp(:, 1:syM);
Y1_1 = flatten_adj(t_TXp(:,(syM+1):end), size(Y1_1),1);

t_T2 = flatten(T1,2);
Y1_2 = flatten_adj(prox_nuc(t_T2 + flatten(W3_2,2)/beta, lambda2 ) ,size(Y1_2) ,2);
t_T3 = flatten(T2,3);
Y1_3 = flatten_adj(prox_nuc(t_T3 + flatten(W3_3,3)/beta, lambda3/(beta*sqrt(sizeT(3))) ) ,size(Y1_3) ,3);


% updating dual variables
W1 = W1 + beta*(M1 - X1);
W3_1 = W3_1 + beta*(T1 - Y1_1);
W3_2 = W3_2 + beta*(T1 - Y1_2);
W3_3 = W3_3 + beta*(T2 - Y1_3);

%st = 3*(T1(vT) + T2(vT) + T3(vT) - T(vT)) + W3_2(vT)  + W3_2(vT) + W3_3(vT) ;
%st2 = M1(vX) - X1(vX) + W1(vX);

iter = iter + 1;

if((iter > 500) ) 
    disp(['Iterations:' ,num2str(iter)])
break;
end

end


end




function [M1] = solve_matrix(M, vX, M1, W1,  X1,  beta)

ssT = size(M);
sizeT = prod(ssT);
L = sparse(sizeT,sizeT);
I_ = zeros(sizeT,1);
I_(vX) = 1;
II = diag(ones(sizeT,1));

size(I_);
size(II);

L = diag(I_) + beta*II;



T_ =zeros(ssT);
T_(vX) = M(vX);
R = reshape(T_ , [sizeT,1]) - reshape(W1,[sizeT,1]) + beta*reshape(X1,[sizeT,1]);

r = L\R;

M1 = reshape(r, ssT );

end

