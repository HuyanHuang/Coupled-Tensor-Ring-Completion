% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

function T = cp_create(u1,u2,u3,l)

size1 = size(u1,2);
size2 = size(u2,2);
size3 = size(u3,1);
sizel = size(l,1);

T = zeros(size(u1,1),size(u2,1),size(u3,1));

for i = 1:sizel
    m = l(i)*u1(:,i)*u2(:,i)';
    for j = 1:size3
        T(:,:,j) = T(:,:,j) + u3(j,i)*m; 
    end
end

end