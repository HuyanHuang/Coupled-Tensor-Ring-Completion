function simulate_scaled_UCLAF() 

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com


%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

ssize = 3;

X = load('c1_aaa1.mat');

res = zeros(1,20);
t = zeros(1,20);
ti = zeros(1,20);

ind = X.sz;


for it = 1:10
for j = 1:ssize

train = X.X.train{it}{j};
val = X.X.val{it}{j};
test = X.X.test{it}{j};
T = X.X.T{it};

lambda = exp(linspace(log(0.01), log(1000), 50));  
spg =  size(lambda , 2);

cv = zeros(spg ,1 );

[I,J,K]=ind2sub(ind,train);
ytrain = T(train);
yval = T(val);
ytest = T(test);

tol = 0.001;


parfor i = 1:spg

[X1,Z1,fval1,gval1] = tensormix2_adm( zeros(ind) ,{I,J,K}, ytrain, lambda(1,i) , 1, tol);
cv(i,1) =norm(X1(val) - yval );
cv_(i,1) = norm(round(X1(val)) - round(T(val)));


end

cv1{it}{j} = cv;
mindx = find(min(cv) == cv);


[I,J,K]=ind2sub(ind,train);


[X1,Z1,fval1,gval1]=tensormix2_adm(zeros(ind), {I,J,K} , ytrain, lambda(1,mindx(1,1)) , 1, tol);
res(j,it) =norm(X1(test) - ytest );

WZ{it} = Z1;
WX{it} = X1;



sname = strcat('res_only_sct' , num2str(it), num2str(ssize), '.mat');
save(sname, 'res');
sname = strcat('cvst_only_sct' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'cv1');
sname = strcat('WZ_only_sct' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'WZ');
sname = strcat('WX_only_sct' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'WX');


end
end



end
