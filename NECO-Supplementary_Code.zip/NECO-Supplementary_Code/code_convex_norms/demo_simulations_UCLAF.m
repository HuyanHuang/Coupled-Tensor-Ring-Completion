% simulate_scaled_UCLAF();
simulate_overlapped_UCLAF();
% simulate_coupled_overlapped_dual_full_matrix();
% simulate_coupled_overlapped_full_matrix();
% simulate_coupled_mixed_full_matrix_dual_1_2();
% simulate_coupled_mixed_full_matrix_dual_1_3();
% simulate_coupled_mixed_full_matrix_dual_2_3();