simulate_matrix();
simulate_overlapped();
simulate_scaled_latent();
simulate_coupled_overlapped();
simulate_coupled_sc_dual();
simulate_coupled_mixed_1b();
simulate_coupled_mixed_2b();
simulate_coupled_mixed_3b();


