function [ZT_1, ZT_2, ZT_3, ZM] = ten_matrix_coupled_mode1_latent_dual(T, M, indT, indM, beta, lambda1, lambda2, lambda3)

% ten_matrix_coupled_mode1_latent implements the dual formulation of
% the coupeld completion using the coupled norm \|.,.\|_{(S,S,S)}. 
% T - coupled tensor
% M - coupled matrix 
% indT - indexes of the observed elements of T
% indM - indexes of the observed elements of M
% beta - proximity parameter for ADMM
% lambda1 - regularization parameter with respect to mode 1
% lambda2 - regularization parameter with respect to mode 2
% lambda3 - regularization parameter with respect to mode 3
% ZT_1,ZT_2,ZT_3 - completed latent tensors
% ZM - completed matrix

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

sizeT = size(T);
[sxM syM] = size(M);
tdim = ndims(T);

vT = indT;
vM = indM;

vT_compl = 1:prod(size(T));
vM_compl = 1:prod(size(M));
vT_compl(vT) = [];
vM_compl(vM) = [];

%alpha_M = zeros(size(M));


ZM = zeros(size(M));
ZT_1 = zeros(size(T));
ZT_2 = zeros(size(T));
ZT_3 = zeros(size(T));

WM = zeros(size(M));
WT_1 = zeros(size(T));
WT_2 = zeros(size(T));
WT_3 = zeros(size(T));


iter = 0;

ssT = size(T);
sizeTp = prod(ssT);
I_ = zeros(ssT);
I_(vT) = 1;
I_ = reshape(I_ , [sizeTp,1]);
II = diag(ones(sizeTp,1));
L = beta*tdim*II + diag(I_);
T_ =zeros(ssT);
T_(vT) = T(vT);

ssM = size(M);
sizeM = prod(ssM);
IM_ = zeros(ssM);
IM_(vM) = 1;
IM_  = reshape(IM_ , [sizeM,1]);
IIM = diag(ones(sizeM,1));
L2 = beta*IIM + diag(IM_);
M_ =zeros(ssM);
M_(vM) = M(vM);


while true

t_Z = ZT_1 + ZT_2 + ZT_3;
t_W = WT_1 + WT_2 + WT_3;
t_Z(vT_compl) = 0;
t_W(vT_compl) = 0;
RT = reshape(T_ , [sizeTp,1]) - reshape( t_Z ,[sizeTp,1]) +  beta*reshape( t_W,[sizeTp,1])  ;
alpha_T = reshape(L\RT, size(T));

t_Z = ZM;
t_W = WM;
t_Z(vM_compl) = 0;
t_W(vM_compl) = 0;
RM = reshape(M_ , [sizeM,1]) - reshape( t_Z ,[sizeM,1]) +  beta*reshape( t_W  ,[sizeM,1])  ;
alpha_M = reshape(L2\RM, size(M));

t_alpha_M = alpha_M;
t_alpha_M(vM_compl) = 0;
t_alpha_T = alpha_T;
t_alpha_T(vT_compl) = 0;
t_TX = [t_alpha_M flatten(t_alpha_T,1)];
t_Z = [ZM flatten(ZT_1,1)];
t_TXp = prox_spec_sc(t_TX + t_Z/beta, lambda1/(sqrt(sizeT(1)))  );
WM = t_TXp(:, 1:syM);
WT_1 = flatten_adj(t_TXp(:,(syM+1):end), size(WT_1) , 1);
t_T2 = flatten(t_alpha_T,2);
WT_2 = flatten_adj(prox_spec_sc(t_T2 + flatten(ZT_2,2)/beta, lambda2/(sqrt(sizeT(2)))  ) ,size(WT_2) ,2);
t_T3 = flatten(t_alpha_T,3);
WT_3 = flatten_adj(prox_spec_sc(t_T3 + flatten(ZT_3,3)/beta, lambda3/(sqrt(sizeT(3)))  ) ,size(WT_3) ,3);


% updating dual variables
ZM = ZM + beta*(t_alpha_M - WM);
ZT_1 = ZT_1 + beta*(t_alpha_T - WT_1);
ZT_2 = ZT_2 + beta*(t_alpha_T - WT_2);
ZT_3 = ZT_3 + beta*(t_alpha_T - WT_3);


iter = iter + 1;

trace_nom_T = (lambda1/sqrt(sizeT(1)))*sum(svd([flatten(ZT_1,1) ZM]) ) + (lambda2/sqrt(sizeT(2)))*sum(svd(flatten(ZT_2,2)))  + (lambda3/sqrt(sizeT(3)))*sum(svd(flatten(ZT_3,3)));
primal = ZT_1 + ZT_2 + ZT_3;
obj_primal = 0.5*sum(sum(sum((primal(indT) - T(indT)).^2)))+ 0.5*sum(sum(sum((ZM(indM) - M(indM)).^2))) + trace_nom_T;  %+ (lambda1/sqrt(sizeT(1)))*sum(svd(ZM))


ss1 =  ( 1/pcaspec([flatten(WT_1, 1) WM]/(lambda1/sqrt(sizeT(1))) ,1,10) ) ;
ss2 =  ( 1/pcaspec(flatten(WT_2/(lambda2/sqrt(sizeT(2)))  ,2) , 1 ,10) );
ss3 =  ( 1/pcaspec(flatten(WT_3/(lambda3/sqrt(sizeT(3)))  ,3) , 1 ,10) ) ;
t_alpha_T_scaled  = alpha_T*min([1 , ss1 , ss2 , ss3 ]);
t_alpha_M_scaled = alpha_M*min([1 , ss1]);


obj_dual = 0.5*norm(t_alpha_T_scaled(:))^2 - sum(sum(sum(t_alpha_T_scaled.*T_))) +  0.5*norm(t_alpha_M_scaled(:))^2 - sum(sum(sum(t_alpha_M_scaled.*M_)));

%abs((obj_primal + obj_dual)/obj_primal);

% Checking duality gap as a stopping condition
if(((iter > 10) && abs((obj_primal + obj_dual)/obj_primal) < 0.05) || iter > 1500 ) % ||  (iter > 30 && norm(st) < 0.005 && norm(st2) < 0.005) ) % norm(M1(:) - X1(:)) < 0.001   && norm(T1(:) - Y1_1(:)) < 0.001  && norm(T1(:) - Y1_2(:)) < 0.001  && norm(T1(:) - Y1_3(:)) < 0.001 ) )
%obj_primal
%obj_dual
%(obj_primal + obj_dual)/obj_primal
disp(['Iterations: ' ,num2str(iter)])
disp(['Duality gap: ' , num2str(abs((obj_primal + obj_dual)/obj_primal))])
break;
end

end
%iter

end




