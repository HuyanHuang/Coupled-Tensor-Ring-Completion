% This program randomly generates coupled tensors using the Tucker rank.
% There is no sharing among coupled tensors.

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.

clear all;

sz=[20 20 20];
szm=[20 30];

tr = [ 0.3,0.5,0.7];
vs = 0.1;

dtrue=[5,5,5]; % Tensor multilinear rank
dmtrue=[5];    % Matrix  rank
ssize = prod(sz);
msize = prod(szm);


for k = 1:10
T = randtensor3(sz,dtrue) + normrnd(0.0, 0.01,  sz(1),sz(2), sz(3)) ;
M = randmatrix(szm,dmtrue) + normrnd(0.0, 0.01, szm(1), szm(2));
size(T)
size(M)

for i = 1:3

pm = randperm(ssize);
pmat = randperm(msize);

X.train{k}{i} = pm(1:floor(tr(i)*ssize));
X.val{k}{i}   = pm( (floor(tr(i)*ssize)+1):(floor(tr(i)*ssize) + floor(vs*ssize) ) );
X.test{k}{i}  = pm((floor(tr(i)*ssize) + floor(vs*ssize) +1):end);

X.trainM{k}{i} = pmat(1:floor(tr(i)*msize));
X.valM{k}{i}   = pmat((floor(tr(i)*msize)+1):(floor(tr(i)*msize) + floor(vs*msize) ) );
X.testM{k}{i}  = pmat((floor(tr(i)*msize) + floor(vs*msize) +1):end);

end
X.T{k} = T;
X.M{k} = M;
end



save c1.mat 
