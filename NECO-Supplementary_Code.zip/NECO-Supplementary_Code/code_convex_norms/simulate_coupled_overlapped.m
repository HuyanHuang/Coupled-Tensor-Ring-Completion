function simulate_coupled_overlapped()

% Copyright (C) 2018  Kishan Wimalawarne
% Kyoto University, Gokasho,Uji,Kyoto,611-0011, Japan. kishanwn@gmail.com

%Copyright 2018 Kishan Wimalawarne

%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
%documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
%the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
%to permit persons to whom the Software is furnished to do so, subject to the following conditions:

%The above copyright notice and this permission notice shall be included in all copies or substantial portions
%of the Software.

%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
%TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
%THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
%CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
%IN THE SOFTWARE.


ssize = 3;

fname = strcat('c1.mat');
X = load(fname);

res = zeros(1,20);
res_m = zeros(1,20);
res_t = zeros(1,20);


for it = 1:10
for j = 1:ssize


Ttr = X.X.train{it}{j}';
Tv = X.X.val{it}{j}';
Tt = X.X.test{it}{j}';

Mtr = X.X.trainM{it}{j}';
Mv = X.X.valM{it}{j}';
Mt = X.X.testM{it}{j}';

T = X.X.T{it};
M = X.X.M{it};


lambda = 0.01:0.05:10
spg = size(lambda , 2);

cv = zeros(spg ,1 );




parfor i = 1:spg
err = 0;

[T_1,  M1] = ten_matrix_coupled_mode1_overlap(T, M, Ttr, Mtr, 1.0, lambda(i), lambda(i), lambda(i));
T1 =  T_1;
cv(i,1) = norm(T1(Tv) - T(Tv)) + norm(M1(Mv) - M(Mv));


end

mindx = find(min(cv) == cv);
mindx
cv1{it}{j} = cv;


[T_1,  M1] = ten_matrix_coupled_mode1_overlap(T, M, Ttr, Mtr, 1.0, lambda(1,mindx(1,1)), lambda(1,mindx(1,1)), lambda(1,mindx(1,1)));
T1 =  T_1 ;
res(j,it) =  norm(T1(Tt) - T(Tt)) + norm(M1(Mt) - M(Mt));
res_m(j,it) = norm(M1(Mt) - M(Mt));
res_t(j,it) = norm(T1(Tt) - T(Tt));

WM{it} = M1;
WT{it} = T_1;



sname = strcat('res_cp_ot_' , num2str(it), num2str(ssize), '.mat');
save(sname, 'res_t');
sname = strcat('res_cp_om_' , num2str(it), num2str(ssize), '.mat');
save(sname, 'res_m');
sname = strcat('cv_cp_o_' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'cv1');
sname = strcat('WM_cp_o_' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'WM');
sname = strcat('WT_cp_o_' , num2str(it), num2str(ssize)  , '.mat');
save(sname, 'WT');


end
end



end
